// pages/RegisterPage.tsx

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  HiOutlineUser as User,
  HiOutlineEnvelope as Email,
  HiOutlineLockClosed as Lock,
  HiOutlinePhone as Phone,
  HiOutlineCalendar as Calendar,
  HiOutlineEye as Eye,
  HiOutlineEyeSlash as EyeOff,
  HiArrowLeft,
  HiOutlineCheckCircle as CheckCircle,
  HiOutlineIdentification as ID,
  HiOutlineBriefcase as Briefcase,
  HiXMark as X,
  HiOutlineMapPin as MapPin
} from 'react-icons/hi2';
import { useAuth } from '../hooks/useAuth';
import { useNotifications } from '../components/UI';
import { useGeography } from '../hooks/useMetadata'; // Import direct du hook
import PhotoUpload from '../components/UI/PhotoUpload';
import { validation } from '../utils';
import type { TypeUtilisateur, RegisterData } from '../types/user';
import { TYPES_UTILISATEUR_OPTIONS } from '../types/user';

const RegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const { register, isAuthenticated } = useAuth();
  const { addNotification } = useNotifications();
  
  // Utiliser le hook useGeography
  const { 
    wilayas, 
    wilayaOptions, 
    wilayasPrincipales,
    isLoading: loadingWilayas,
    error: wilayasError
  } = useGeography();

  // Debug
  useEffect(() => {
    console.log('📊 État des wilayas:', {
      total: wilayas.length,
      options: wilayaOptions.length,
      principales: wilayasPrincipales.length,
      loading: loadingWilayas,
      error: wilayasError
    });
  }, [wilayas, wilayaOptions, wilayasPrincipales, loadingWilayas, wilayasError]);

  // Utilisation des types depuis les constantes
  const professionalTypes = TYPES_UTILISATEUR_OPTIONS.filter(type => type.value !== 'visiteur');

  // Redirection si déjà connecté
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/', { replace: true });
    }
  }, [isAuthenticated, navigate]);

  // Gérer les erreurs de chargement des wilayas
  useEffect(() => {
    if (wilayasError) {
      console.error('❌ Erreur lors du chargement des wilayas:', wilayasError);
      addNotification({
        type: 'warning',
        title: 'Attention',
        message: 'Impossible de charger la liste des wilayas'
      });
    }
  }, [wilayasError, addNotification]);

  // États du formulaire
  const [step, setStep] = useState(1);
  const [accountType, setAccountType] = useState<'visiteur' | 'professionnel'>('visiteur');
  const [formData, setFormData] = useState({
    nom: '',
    prenom: '',
    email: '',
    password: '',
    confirmPassword: '',
    telephone: '',
    date_naissance: '',
    sexe: '' as 'M' | 'F' | '',
    wilaya_residence: '',
    type_user: 'visiteur' as TypeUtilisateur,
    bio: '',
    photo_profil: null as File | null,
    specialites: [] as string[],
    accepte_newsletter: false
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [newSpecialite, setNewSpecialite] = useState('');

  // Styles personnalisés
  const customStyles = {
    bgPrimary: 'bg-[#f8fbfa]',
    textPrimary: 'text-[#0e1a13]',
    textSecondary: 'text-[#51946b]',
    bgSecondary: 'bg-[#e8f2ec]',
    bgAccent: 'bg-[#eb9f13]',
    borderColor: 'border-[#e8f2ec]',
    hoverAccent: 'hover:text-[#eb9f13]',
    textAccent: 'text-[#eb9f13]',
    inputBorder: 'border-[#dde0e3]',
    inputFocus: 'focus:border-[#eb9f13]',
    textMuted: 'text-[#6a7581]'
  };

  const handlePhotoChange = (file: File | null) => {
    setFormData(prev => ({
      ...prev,
      photo_profil: file
    }));
    if (errors.photo_profil) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors.photo_profil;
        return newErrors;
      });
    }
  };

  const addSpecialite = () => {
    if (newSpecialite.trim() && !formData.specialites.includes(newSpecialite.trim())) {
      setFormData(prev => ({
        ...prev,
        specialites: [...prev.specialites, newSpecialite.trim()]
      }));
      setNewSpecialite('');
    }
  };

  const removeSpecialite = (specialite: string) => {
    setFormData(prev => ({
      ...prev,
      specialites: prev.specialites.filter(s => s !== specialite)
    }));
  };

  const validateStep = (currentStep: number): boolean => {
    const newErrors: Record<string, string> = {};

    if (currentStep === 2) {
      if (!formData.nom.trim()) {
        newErrors.nom = 'Le nom est requis';
      }
      if (!formData.prenom.trim()) {
        newErrors.prenom = 'Le prénom est requis';
      }
      if (!formData.email.trim()) {
        newErrors.email = 'L\'email est requis';
      } else if (!validation.email(formData.email)) {
        newErrors.email = 'Email invalide';
      }
      if (!formData.password) {
        newErrors.password = 'Le mot de passe est requis';
      } else {
        const passwordValidation = validation.password(formData.password);
        if (!passwordValidation.valid) {
          newErrors.password = passwordValidation.errors[0];
        }
      }
      if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = 'Les mots de passe ne correspondent pas';
      }
      if (formData.telephone && !validation.phone(formData.telephone)) {
        newErrors.telephone = 'Numéro de téléphone invalide';
      }
      if (!formData.date_naissance) {
        newErrors.date_naissance = 'La date de naissance est requise';
      }
    }

    if (currentStep === 3 && accountType === 'professionnel') {
      if (!formData.type_user || formData.type_user === 'visiteur') {
        newErrors.type_user = 'Veuillez sélectionner votre profession';
      }
      if (!formData.bio.trim()) {
        newErrors.bio = 'La biographie professionnelle est requise';
      }
      if (formData.specialites.length === 0) {
        newErrors.specialites = 'Veuillez ajouter au moins une spécialité';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNextStep = () => {
    if (validateStep(step)) {
      if (step === 1) {
        setFormData(prev => ({
          ...prev,
          type_user: accountType === 'visiteur' ? 'visiteur' : prev.type_user
        }));
      }
      
      if (step === 2 && accountType === 'visiteur') {
        handleSubmit();
      } else {
        setStep(step + 1);
      }
    }
  };

  const handlePreviousStep = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleSubmit = async () => {
    const isValid = accountType === 'professionnel' ? validateStep(3) : true;
    if (!isValid) return;

    if (!acceptedTerms) {
      setErrors({ terms: 'Vous devez accepter les conditions d\'utilisation' });
      return;
    }

    setIsLoading(true);
    try {
      const registrationData: RegisterData = {
        nom: formData.nom,
        prenom: formData.prenom,
        email: formData.email,
        password: formData.password,
        confirm_password: formData.confirmPassword,
        telephone: formData.telephone || undefined,
        date_naissance: formData.date_naissance,
        sexe: formData.sexe as 'M' | 'F' | undefined,
        wilaya_residence: formData.wilaya_residence 
          ? parseInt(formData.wilaya_residence, 10) 
          : undefined,
        type_user: formData.type_user,
        bio: formData.bio || undefined,
        photo_profil: formData.photo_profil || undefined,
        specialites: formData.specialites.length > 0 ? formData.specialites : undefined,
        accepte_conditions: acceptedTerms,
        accepte_newsletter: formData.accepte_newsletter
      };

      await register(registrationData);
      
      addNotification({
        type: 'success',
        title: 'Inscription réussie !',
        message: accountType === 'professionnel' 
          ? 'Votre compte professionnel a été créé. Il sera validé par un administrateur.'
          : 'Bienvenue dans la communauté Timlilit Culture !'
      });
    } catch (error: any) {
      const message = error?.message || 'Erreur lors de l\'inscription';
      setErrors({ general: message });
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (field: keyof typeof formData) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [field]: e.target.value
    }));
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const ProgressIndicator = () => (
    <div className="flex items-center justify-center mb-8">
      <div className="flex items-center gap-4">
        {[1, 2, 3].map((stepNumber) => {
          const isActive = step === stepNumber;
          const isCompleted = step > stepNumber;
          const isHidden = stepNumber === 3 && accountType === 'visiteur';

          if (isHidden) return null;

          return (
            <React.Fragment key={stepNumber}>
              <div className="flex items-center gap-2">
                <div
                  className={`
                    w-10 h-10 rounded-full flex items-center justify-center font-bold transition-colors
                    ${isActive ? customStyles.bgAccent + ' text-white' : ''}
                    ${isCompleted ? 'bg-[#51946b] text-white' : ''}
                    ${!isActive && !isCompleted ? 'bg-gray-200 text-gray-500' : ''}
                  `}
                >
                  {isCompleted ? <CheckCircle className="w-6 h-6" /> : stepNumber}
                </div>
                <span className={`text-sm ${isActive ? customStyles.textPrimary : customStyles.textMuted}`}>
                  {stepNumber === 1 && 'Type de compte'}
                  {stepNumber === 2 && 'Informations personnelles'}
                  {stepNumber === 3 && 'Profil professionnel'}
                </span>
              </div>
              {stepNumber < (accountType === 'visiteur' ? 2 : 3) && (
                <div className={`w-12 h-0.5 ${step > stepNumber ? 'bg-[#51946b]' : 'bg-gray-300'}`} />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className={`relative flex size-full min-h-screen flex-col ${customStyles.bgPrimary} group/design-root overflow-x-hidden`} style={{ fontFamily: '"Noto Serif", "Noto Sans", sans-serif' }}>
      <div className="layout-container flex h-full grow flex-col">
        
        {/* Header simplifié */}
        <header className={`flex items-center justify-between whitespace-nowrap border-b border-solid ${customStyles.borderColor} px-10 py-3`}>
          <Link to="/" className={`flex items-center gap-4 ${customStyles.textPrimary}`}>
            <div className="size-4">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M4 42.4379C4 42.4379 14.0962 36.0744 24 41.1692C35.0664 46.8624 44 42.2078 44 42.2078L44 7.01134C44 7.01134 35.068 11.6577 24.0031 5.96913C14.0971 0.876274 4 7.27094 4 7.27094L4 42.4379Z"
                  fill="currentColor"
                ></path>
              </svg>
            </div>
            <h2 className={`${customStyles.textPrimary} text-lg font-bold leading-tight tracking-[-0.015em]`}>Timlilit Culture</h2>
          </Link>
          
          <Link
            to="/"
            className={`flex items-center gap-2 ${customStyles.textSecondary} text-sm font-medium ${customStyles.hoverAccent} transition-colors`}
          >
            <HiArrowLeft className="w-4 h-4" />
            Retour à l'accueil
          </Link>
        </header>

        {/* Contenu principal */}
        <div className="px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-[640px] max-w-[640px] py-5">
            
            {/* Titre */}
            <div className="text-center mb-6">
              <h2 className={`${customStyles.textPrimary} tracking-light text-[32px] font-bold leading-tight px-4 pb-2`}>
                Rejoignez Timlilit Culture
              </h2>
              <p className={`${customStyles.textMuted} text-base`}>
                Créez votre compte pour partager le patrimoine culturel algérien
              </p>
            </div>

            {/* Indicateur de progression */}
            <ProgressIndicator />

            {/* Message d'erreur général */}
            {errors.general && (
              <div className="mx-4 mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-600 text-sm">{errors.general}</p>
              </div>
            )}

            {/* Étape 1: Type de compte */}
            {step === 1 && (
              <div className="space-y-6">
                <h3 className={`${customStyles.textPrimary} text-xl font-semibold text-center mb-6`}>
                  Choisissez votre type de compte
                </h3>

                <div className="grid grid-cols-2 gap-4 px-4">
                  {/* Visiteur */}
                  <div
                    onClick={() => setAccountType('visiteur')}
                    className={`
                      cursor-pointer rounded-xl border-2 p-6 transition-all
                      ${accountType === 'visiteur' 
                        ? `border-[#eb9f13] ${customStyles.bgSecondary}` 
                        : `${customStyles.inputBorder} hover:border-[#eb9f13]/50`
                      }
                    `}
                  >
                    <div className="flex flex-col items-center text-center gap-3">
                      <User className={`w-12 h-12 ${accountType === 'visiteur' ? customStyles.textAccent : customStyles.textMuted}`} />
                      <h4 className={`${customStyles.textPrimary} font-semibold`}>Visiteur</h4>
                      <p className={`${customStyles.textMuted} text-sm`}>
                        Découvrez et explorez le patrimoine culturel algérien
                      </p>
                      <ul className="text-left text-xs space-y-1 mt-2">
                        <li className="flex items-start gap-1">
                          <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                          <span>Parcourir les œuvres et événements</span>
                        </li>
                        <li className="flex items-start gap-1">
                          <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                          <span>Participer aux événements</span>
                        </li>
                        <li className="flex items-start gap-1">
                          <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                          <span>Commenter et évaluer</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  {/* Professionnel */}
                  <div
                    onClick={() => setAccountType('professionnel')}
                    className={`
                      cursor-pointer rounded-xl border-2 p-6 transition-all
                      ${accountType === 'professionnel' 
                        ? `border-[#eb9f13] ${customStyles.bgSecondary}` 
                        : `${customStyles.inputBorder} hover:border-[#eb9f13]/50`
                      }
                    `}
                  >
                    <div className="flex flex-col items-center text-center gap-3">
                      <Briefcase className={`w-12 h-12 ${accountType === 'professionnel' ? customStyles.textAccent : customStyles.textMuted}`} />
                      <h4 className={`${customStyles.textPrimary} font-semibold`}>Professionnel</h4>
                      <p className={`${customStyles.textMuted} text-sm`}>
                        Créez et partagez vos œuvres culturelles
                      </p>
                      <ul className="text-left text-xs space-y-1 mt-2">
                        <li className="flex items-start gap-1">
                          <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                          <span>Publier vos œuvres</span>
                        </li>
                        <li className="flex items-start gap-1">
                          <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                          <span>Organiser des événements</span>
                        </li>
                        <li className="flex items-start gap-1">
                          <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                          <span>Profil professionnel vérifié</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="flex justify-center px-4 pt-4">
                  <button
                    onClick={handleNextStep}
                    className={`
                      px-8 py-3 rounded-full font-bold transition-all
                      ${customStyles.bgAccent} ${customStyles.textPrimary}
                      hover:opacity-90
                    `}
                  >
                    Continuer
                  </button>
                </div>
              </div>
            )}

            {/* Étape 2: Informations personnelles */}
            {step === 2 && (
              <div className="space-y-4">
                <h3 className={`${customStyles.textPrimary} text-xl font-semibold text-center mb-6`}>
                  Informations personnelles
                </h3>

                <div className="grid grid-cols-2 gap-4 px-4">
                  {/* Nom */}
                  <div>
                    <label className="flex flex-col">
                      <span className={`${customStyles.textPrimary} text-sm font-medium mb-2`}>Nom</span>
                      <div className="relative">
                        <input
                          type="text"
                          placeholder="Votre nom"
                          className={`
                            form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl 
                            ${customStyles.textPrimary} focus:outline-0 focus:ring-2 focus:ring-[#eb9f13]/20
                            border ${errors.nom ? 'border-red-500' : customStyles.inputBorder} 
                            bg-white ${customStyles.inputFocus} h-12 
                            placeholder:${customStyles.textMuted} pl-10 pr-4 
                            text-base font-normal leading-normal transition-all
                          `}
                          value={formData.nom}
                          onChange={handleChange('nom')}
                        />
                        <User className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${customStyles.textMuted}`} />
                      </div>
                      {errors.nom && <p className="text-red-500 text-xs mt-1">{errors.nom}</p>}
                    </label>
                  </div>

                  {/* Prénom */}
                  <div>
                    <label className="flex flex-col">
                      <span className={`${customStyles.textPrimary} text-sm font-medium mb-2`}>Prénom</span>
                      <div className="relative">
                        <input
                          type="text"
                          placeholder="Votre prénom"
                          className={`
                            form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl 
                            ${customStyles.textPrimary} focus:outline-0 focus:ring-2 focus:ring-[#eb9f13]/20
                            border ${errors.prenom ? 'border-red-500' : customStyles.inputBorder} 
                            bg-white ${customStyles.inputFocus} h-12 
                            placeholder:${customStyles.textMuted} pl-10 pr-4 
                            text-base font-normal leading-normal transition-all
                          `}
                          value={formData.prenom}
                          onChange={handleChange('prenom')}
                        />
                        <User className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${customStyles.textMuted}`} />
                      </div>
                      {errors.prenom && <p className="text-red-500 text-xs mt-1">{errors.prenom}</p>}
                    </label>
                  </div>
                </div>

                {/* Email */}
                <div className="px-4">
                  <label className="flex flex-col">
                    <span className={`${customStyles.textPrimary} text-sm font-medium mb-2`}>Email</span>
                    <div className="relative">
                      <input
                        type="email"
                        placeholder="votre.email@exemple.com"
                        className={`
                          form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl 
                          ${customStyles.textPrimary} focus:outline-0 focus:ring-2 focus:ring-[#eb9f13]/20
                          border ${errors.email ? 'border-red-500' : customStyles.inputBorder} 
                          bg-white ${customStyles.inputFocus} h-12 
                          placeholder:${customStyles.textMuted} pl-10 pr-4 
                          text-base font-normal leading-normal transition-all
                        `}
                        value={formData.email}
                        onChange={handleChange('email')}
                      />
                      <Email className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${customStyles.textMuted}`} />
                    </div>
                    {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
                  </label>
                </div>

                <div className="grid grid-cols-2 gap-4 px-4">
                  {/* Mot de passe */}
                  <div>
                    <label className="flex flex-col">
                      <span className={`${customStyles.textPrimary} text-sm font-medium mb-2`}>Mot de passe</span>
                      <div className="relative">
                        <input
                          type={showPassword ? 'text' : 'password'}
                          placeholder="••••••••"
                          className={`
                            form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl 
                            ${customStyles.textPrimary} focus:outline-0 focus:ring-2 focus:ring-[#eb9f13]/20
                            border ${errors.password ? 'border-red-500' : customStyles.inputBorder} 
                            bg-white ${customStyles.inputFocus} h-12 
                            placeholder:${customStyles.textMuted} pl-10 pr-10 
                            text-base font-normal leading-normal transition-all
                          `}
                          value={formData.password}
                          onChange={handleChange('password')}
                        />
                        <Lock className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${customStyles.textMuted}`} />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className={`absolute right-3 top-1/2 -translate-y-1/2 ${customStyles.textMuted} hover:${customStyles.textPrimary}`}
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      {errors.password && <p className="text-red-500 text-xs mt-1">{errors.password}</p>}
                    </label>
                  </div>

                  {/* Confirmer mot de passe */}
                  <div>
                    <label className="flex flex-col">
                      <span className={`${customStyles.textPrimary} text-sm font-medium mb-2`}>Confirmer</span>
                      <div className="relative">
                        <input
                          type={showConfirmPassword ? 'text' : 'password'}
                          placeholder="••••••••"
                          className={`
                            form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl 
                            ${customStyles.textPrimary} focus:outline-0 focus:ring-2 focus:ring-[#eb9f13]/20
                            border ${errors.confirmPassword ? 'border-red-500' : customStyles.inputBorder} 
                            bg-white ${customStyles.inputFocus} h-12 
                            placeholder:${customStyles.textMuted} pl-10 pr-10 
                            text-base font-normal leading-normal transition-all
                          `}
                          value={formData.confirmPassword}
                          onChange={handleChange('confirmPassword')}
                        />
                        <Lock className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${customStyles.textMuted}`} />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className={`absolute right-3 top-1/2 -translate-y-1/2 ${customStyles.textMuted} hover:${customStyles.textPrimary}`}
                        >
                          {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      {errors.confirmPassword && <p className="text-red-500 text-xs mt-1">{errors.confirmPassword}</p>}
                    </label>
                  </div>
                </div>

                {/* Sexe */}
                <div className="px-4">
                  <label className="flex flex-col">
                    <span className={`${customStyles.textPrimary} text-sm font-medium mb-2`}>Sexe (optionnel)</span>
                    <div className="flex gap-4">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="sexe"
                          value="M"
                          checked={formData.sexe === 'M'}
                          onChange={(e) => setFormData(prev => ({ ...prev, sexe: e.target.value as 'M' }))}
                          className="text-[#eb9f13] focus:ring-[#eb9f13]"
                        />
                        <span className={customStyles.textPrimary}>Homme</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="sexe"
                          value="F"
                          checked={formData.sexe === 'F'}
                          onChange={(e) => setFormData(prev => ({ ...prev, sexe: e.target.value as 'F' }))}
                          className="text-[#eb9f13] focus:ring-[#eb9f13]"
                        />
                        <span className={customStyles.textPrimary}>Femme</span>
                      </label>
                    </div>
                  </label>
                </div>

                <div className="grid grid-cols-2 gap-4 px-4">
                  {/* Téléphone */}
                  <div>
                    <label className="flex flex-col">
                      <span className={`${customStyles.textPrimary} text-sm font-medium mb-2`}>Téléphone (optionnel)</span>
                      <div className="relative">
                        <input
                          type="tel"
                          placeholder="0XX XX XX XX XX"
                          className={`
                            form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl 
                            ${customStyles.textPrimary} focus:outline-0 focus:ring-2 focus:ring-[#eb9f13]/20
                            border ${errors.telephone ? 'border-red-500' : customStyles.inputBorder} 
                            bg-white ${customStyles.inputFocus} h-12 
                            placeholder:${customStyles.textMuted} pl-10 pr-4 
                            text-base font-normal leading-normal transition-all
                          `}
                          value={formData.telephone}
                          onChange={handleChange('telephone')}
                        />
                        <Phone className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${customStyles.textMuted}`} />
                      </div>
                      {errors.telephone && <p className="text-red-500 text-xs mt-1">{errors.telephone}</p>}
                    </label>
                  </div>

                  {/* Date de naissance */}
                  <div>
                    <label className="flex flex-col">
                      <span className={`${customStyles.textPrimary} text-sm font-medium mb-2`}>Date de naissance</span>
                      <div className="relative">
                        <input
                          type="date"
                          className={`
                            form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl 
                            ${customStyles.textPrimary} focus:outline-0 focus:ring-2 focus:ring-[#eb9f13]/20
                            border ${errors.date_naissance ? 'border-red-500' : customStyles.inputBorder} 
                            bg-white ${customStyles.inputFocus} h-12 
                            placeholder:${customStyles.textMuted} pl-10 pr-4 
                            text-base font-normal leading-normal transition-all
                          `}
                          value={formData.date_naissance}
                          onChange={handleChange('date_naissance')}
                          max={new Date().toISOString().split('T')[0]}
                        />
                        <Calendar className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${customStyles.textMuted}`} />
                      </div>
                      {errors.date_naissance && <p className="text-red-500 text-xs mt-1">{errors.date_naissance}</p>}
                    </label>
                  </div>
                </div>

                {/* Wilaya de résidence */}
                <div className="px-4">
                  <label className="flex flex-col">
                    <span className={`${customStyles.textPrimary} text-sm font-medium mb-2`}>
                      Wilaya de résidence (optionnel)
                    </span>
                    <div className="relative">
                      <select
                        className={`
                          form-select flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl 
                          ${customStyles.textPrimary} focus:outline-0 focus:ring-2 focus:ring-[#eb9f13]/20
                          border ${errors.wilaya_residence ? 'border-red-500' : customStyles.inputBorder} 
                          bg-white ${customStyles.inputFocus} h-12 
                          pl-10 pr-10 text-base font-normal leading-normal transition-all appearance-none
                          ${loadingWilayas ? 'opacity-50 cursor-wait' : ''}
                        `}
                        value={formData.wilaya_residence}
                        onChange={handleChange('wilaya_residence')}
                        disabled={loadingWilayas}
                      >
                        <option value="">Sélectionnez votre wilaya</option>
                        {loadingWilayas ? (
                          <option disabled>Chargement des wilayas...</option>
                        ) : wilayaOptions.length === 0 ? (
                          <option disabled>Aucune wilaya disponible</option>
                        ) : (
                          wilayaOptions.map((option) => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))
                        )}
                      </select>
                      <MapPin className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${customStyles.textMuted}`} />
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                        <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                      </div>
                    </div>
                    {errors.wilaya_residence && <p className="text-red-500 text-xs mt-1">{errors.wilaya_residence}</p>}
                  </label>
                </div>

                {/* Boutons de navigation */}
                <div className="flex justify-between px-4 pt-6">
                  <button
                    onClick={handlePreviousStep}
                    className={`
                      px-6 py-2 rounded-full font-medium transition-all
                      border ${customStyles.borderColor} ${customStyles.textPrimary}
                      hover:${customStyles.bgSecondary}
                    `}
                  >
                    Retour
                  </button>
                  
                  {accountType === 'visiteur' ? (
                    <div className="flex flex-col items-end gap-2">
                      <label className="flex items-center gap-2 cursor-pointer mb-2">
                        <input
                          type="checkbox"
                          checked={formData.accepte_newsletter}
                          onChange={(e) => setFormData(prev => ({ ...prev, accepte_newsletter: e.target.checked }))}
                          className="rounded border-gray-300 text-[#eb9f13] focus:ring-[#eb9f13]"
                        />
                        <span className={`${customStyles.textMuted} text-sm`}>
                          Je souhaite recevoir la newsletter
                        </span>
                      </label>
                      
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={acceptedTerms}
                          onChange={(e) => setAcceptedTerms(e.target.checked)}
                          className="rounded border-gray-300 text-[#eb9f13] focus:ring-[#eb9f13]"
                        />
                        <span className={`${customStyles.textMuted} text-sm`}>
                          J'accepte les{' '}
                          <Link to="/conditions" className={`${customStyles.textAccent} hover:underline`}>
                            conditions d'utilisation
                          </Link>
                        </span>
                      </label>
                      {errors.terms && <p className="text-red-500 text-xs">{errors.terms}</p>}
                      
                      <button
                        onClick={handleNextStep}
                        disabled={!acceptedTerms || isLoading}
                        className={`
                          px-8 py-3 rounded-full font-bold transition-all
                          ${customStyles.bgAccent} ${customStyles.textPrimary}
                          hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed
                        `}
                      >
                        {isLoading ? (
                          <div className="flex items-center gap-2">
                            <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                            <span>Inscription...</span>
                          </div>
                        ) : (
                          'Créer mon compte'
                        )}
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={handleNextStep}
                      className={`
                        px-8 py-3 rounded-full font-bold transition-all
                        ${customStyles.bgAccent} ${customStyles.textPrimary}
                        hover:opacity-90
                      `}
                    >
                      Continuer
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Étape 3: Informations professionnelles */}
            {step === 3 && accountType === 'professionnel' && (
              <div className="space-y-6">
                <h3 className={`${customStyles.textPrimary} text-xl font-semibold text-center mb-6`}>
                  Profil professionnel
                </h3>

                {/* Section photo de profil */}
                <div className="px-4">
                  <label className="flex flex-col">
                    <span className={`${customStyles.textPrimary} text-sm font-medium mb-4`}>
                      Photo de profil 
                      <span className={`${customStyles.textMuted} font-normal`}>(recommandée)</span>
                    </span>
                    <div className="flex justify-center">
                      <PhotoUpload
                        onPhotoChange={handlePhotoChange}
                        size="lg"
                        className="w-full"
                        maxSize={5}
                        acceptedFormats={['image/jpeg', 'image/png', 'image/gif', 'image/webp']}
                      />
                    </div>
                    {errors.photo_profil && <p className="text-red-500 text-xs mt-2 text-center">{errors.photo_profil}</p>}
                    <p className={`${customStyles.textMuted} text-xs text-center mt-2`}>
                      Une photo de profil améliore votre crédibilité et aide les visiteurs à vous identifier
                    </p>
                  </label>
                </div>

                {/* Type de profession */}
                <div className="px-4">
                  <label className="flex flex-col">
                    <span className={`${customStyles.textPrimary} text-sm font-medium mb-2`}>Votre profession</span>
                    <div className="relative">
                      <select
                        className={`
                          form-select flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl 
                          ${customStyles.textPrimary} focus:outline-0 focus:ring-2 focus:ring-[#eb9f13]/20
                          border ${errors.type_user ? 'border-red-500' : customStyles.inputBorder} 
                          bg-white ${customStyles.inputFocus} h-12 
                          pl-10 pr-10 text-base font-normal leading-normal transition-all appearance-none
                        `}
                        value={formData.type_user}
                        onChange={(e) => setFormData(prev => ({ ...prev, type_user: e.target.value as TypeUtilisateur }))}
                      >
                        <option value="">Sélectionnez votre profession</option>
                        {professionalTypes.map(type => (
                          <option key={type.value} value={type.value}>
                            {type.label}
                          </option>
                        ))}
                      </select>
                      <Briefcase className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${customStyles.textMuted}`} />
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                        <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                      </div>
                    </div>
                    {errors.type_user && <p className="text-red-500 text-xs mt-1">{errors.type_user}</p>}
                  </label>
                </div>

                {/* Biographie professionnelle */}
                <div className="px-4">
                  <label className="flex flex-col">
                    <span className={`${customStyles.textPrimary} text-sm font-medium mb-2`}>Biographie professionnelle</span>
                    <textarea
                      placeholder="Parlez-nous de votre parcours et de votre travail..."
                      className={`
                        form-textarea flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl 
                        ${customStyles.textPrimary} focus:outline-0 focus:ring-2 focus:ring-[#eb9f13]/20
                        border ${errors.bio ? 'border-red-500' : customStyles.inputBorder} 
                        bg-white ${customStyles.inputFocus} min-h-[100px]
                        placeholder:${customStyles.textMuted} p-3 
                        text-base font-normal leading-normal transition-all
                      `}
                      value={formData.bio}
                      onChange={(e) => setFormData(prev => ({ ...prev, bio: e.target.value }))}
                      rows={4}
                    />
                    {errors.bio && <p className="text-red-500 text-xs mt-1">{errors.bio}</p>}
                  </label>
                </div>

                {/* Spécialités */}
                <div className="px-4">
                  <label className="flex flex-col">
                    <span className={`${customStyles.textPrimary} text-sm font-medium mb-2`}>Spécialités</span>
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="Ajouter une spécialité..."
                          className={`
                            form-input flex-1 rounded-xl 
                            ${customStyles.textPrimary} focus:outline-0 focus:ring-2 focus:ring-[#eb9f13]/20
                            border ${customStyles.inputBorder} bg-white ${customStyles.inputFocus} h-10
                            placeholder:${customStyles.textMuted} px-4 
                            text-base font-normal leading-normal transition-all
                          `}
                          value={newSpecialite}
                          onChange={(e) => setNewSpecialite(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              addSpecialite();
                            }
                          }}
                        />
                        <button
                          type="button"
                          onClick={addSpecialite}
                          disabled={!newSpecialite.trim()}
                          className={`px-4 py-2 rounded-xl ${customStyles.bgAccent} ${customStyles.textPrimary} font-medium hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed`}
                        >
                          Ajouter
                        </button>
                      </div>
                      
                      {formData.specialites.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                          {formData.specialites.map((specialite, index) => (
                            <span
                              key={index}
                              className="inline-flex items-center gap-1 px-3 py-1 bg-[#e8f2ec] text-[#51946b] rounded-full text-sm"
                            >
                              {specialite}
                              <button
                                type="button"
                                onClick={() => removeSpecialite(specialite)}
                                className="ml-1 hover:text-[#eb9f13] transition-colors"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                    {errors.specialites && <p className="text-red-500 text-xs mt-1">{errors.specialites}</p>}
                  </label>
                </div>

                {/* Newsletter */}
                <div className="px-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.accepte_newsletter}
                      onChange={(e) => setFormData(prev => ({ ...prev, accepte_newsletter: e.target.checked }))}
                      className="rounded border-gray-300 text-[#eb9f13] focus:ring-[#eb9f13]"
                    />
                    <span className={`${customStyles.textMuted} text-sm`}>
                      Je souhaite recevoir la newsletter avec les actualités culturelles
                    </span>
                  </label>
                </div>

                {/* Note d'information */}
                <div className={`mx-4 p-4 ${customStyles.bgSecondary} rounded-lg`}>
                  <div className="flex items-start gap-3">
                    <ID className="w-5 h-5 text-[#51946b] flex-shrink-0 mt-0.5" />
                    <div>
                      <p className={`${customStyles.textPrimary} text-sm font-medium mb-1`}>
                        Validation du compte professionnel
                      </p>
                      <p className={`${customStyles.textMuted} text-xs`}>
                        Votre compte professionnel sera vérifié par notre équipe dans les 48 heures. 
                        Vous recevrez un email de confirmation une fois votre compte validé.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Conditions d'utilisation */}
                <div className="px-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={acceptedTerms}
                      onChange={(e) => setAcceptedTerms(e.target.checked)}
                      className="rounded border-gray-300 text-[#eb9f13] focus:ring-[#eb9f13]"
                    />
                    <span className={`${customStyles.textMuted} text-sm`}>
                      J'accepte les{' '}
                      <Link to="/conditions" className={`${customStyles.textAccent} hover:underline`}>
                        conditions d'utilisation
                      </Link>
                      {' '}et la{' '}
                      <Link to="/charte-professionnelle" className={`${customStyles.textAccent} hover:underline`}>
                        charte professionnelle
                      </Link>
                    </span>
                  </label>
                  {errors.terms && <p className="text-red-500 text-xs mt-1">{errors.terms}</p>}
                </div>

                {/* Boutons de navigation */}
                <div className="flex justify-between px-4 pt-6">
                  <button
                    onClick={handlePreviousStep}
                    className={`
                      px-6 py-2 rounded-full font-medium transition-all
                      border ${customStyles.borderColor} ${customStyles.textPrimary}
                      hover:${customStyles.bgSecondary}
                    `}
                  >
                    Retour
                  </button>
                  
                  <button
                    onClick={handleSubmit}
                    disabled={!acceptedTerms || isLoading}
                    className={`
                      px-8 py-3 rounded-full font-bold transition-all
                      ${customStyles.bgAccent} ${customStyles.textPrimary}
                      hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed
                    `}
                  >
                    {isLoading ? (
                      <div className="flex items-center gap-2">
                        <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                        <span>Création du compte...</span>
                      </div>
                    ) : (
                      'Créer mon compte professionnel'
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Lien connexion */}
            <p className={`${customStyles.textMuted} text-sm font-normal text-center mt-8`}>
              Déjà inscrit ?{' '}
              <Link 
                to="/connexion" 
                className={`${customStyles.textAccent} font-medium hover:underline`}
              >
                Connectez-vous
              </Link>
            </p>
          </div>
        </div>

        {/* Footer minimal */}
        <footer className="border-t border-[#e8f2ec] py-6">
          <p className={`text-center ${customStyles.textMuted} text-sm`}>
            @2024 Timlilit Culture. Tous droits réservés.
          </p>
        </footer>
      </div>
    </div>
  );
};

export default RegisterPage;