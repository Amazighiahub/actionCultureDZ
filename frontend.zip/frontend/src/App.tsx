// src/App.tsx - Configuration finale avec tous vos composants et hooks

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// 1) Importez tous vos providers dans le bon ordre
import { AuthProvider } from './hooks/useAuth';
import { NotificationProvider } from './components/UI';
import { ErrorBoundary } from './components/providers/ErrorBoundary';
import DetailLieu from './pages/DetailLieu';

// 2) Import des layouts
import MainLayout from './components/Layout/MainLayout';

// 3) Import des pages
import HomePage from './pages/HomePage';
import LoginPage  from './pages/LoginPage';
import  RegisterPage 
from './pages/RegisterPage';
import { OeuvresPage, PatrimoinePage, EvenementsPage } from './pages/ListingPages';
import OeuvreDetail from './pages/OeuvreDetail';


// 4) Import des formulaires (décommentez si les composants existent)
//import OeuvreForm from './components/Forms/CreateOeuvreForm';
//import EvenementForm from './components/Forms/EvenementForm';
//import LieuForm from './components/Forms/CreateLieuForm';

// 5) Import des composants UI
import { Loading } from './components/UI';
import LoadingScreen from './components/UI/LoadingScreen'; // ← ajoutez ceci

// 6) Import des hooks
import { useAuth } from './hooks/useAuth';
import SearchPage from './pages/SearchPage';
import ArtisanatPage from './pages/ArtisanatPage';

// =============================================================================
// COMPOSANT WRAPPER POUR LES ROUTES PROTÉGÉES
// =============================================================================

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiresAuth?: boolean;
  requiresRole?: string[];
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  children, 
  requiresAuth = false,
  requiresRole = []
}) => {
  const { user, isLoading, isAuthenticated } = useAuth();

  if (isLoading) {
    // Soit vous utilisez LoadingScreen…
    return <LoadingScreen />;
    // …soit si vous préférez le composant Loading :
    // return <Loading />;
  }

  if (requiresAuth && !isAuthenticated) {
    window.location.href = '/connexion';
    return <Loading overlay text="Redirection..." />;
  }

  if (requiresRole.length > 0 && user) {
    const userRoles = user.Roles?.map(r => r.nom_role) || [];
    const hasRequiredRole = requiresRole.some(role => userRoles.includes);
    
    if (!hasRequiredRole) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-patrimoine-creme/20">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-patrimoine-canard mb-4">
              Accès non autorisé
            </h1>
            <p className="text-patrimoine-sombre/70 mb-6">
              Vous n'avez pas les permissions nécessaires pour accéder à cette page.
            </p>
            <a
              href="/"
              className="btn-patrimoine inline-block"
            >
              Retour à l'accueil
            </a>
          </div>
        </div>
      );
    }
  }

  return <>{children}</>;
};

// =============================================================================
// COMPOSANT PRINCIPAL APP
// =============================================================================

const App: React.FC = () => {
  return (
    <ErrorBoundary>
      <Router>
        <NotificationProvider>
          {/* ✅ IMPORTANT: AuthProvider doit englober TOUTE l'application */}
          <AuthProvider>
            <div className="min-h-screen bg-patrimoine-creme/10">
              <Routes>
                {/* ═════════════════════════════════════════════════════════════ */}
                {/* ROUTES PUBLIQUES (sans layout pour l'auth) */} 
                {/* ═════════════════════════════════════════════════════════════ */}
                
                <Route path="/connexion" element={<LoginPage />} />
  <Route path="/inscription" element={<RegisterPage />} />
                
                {/* ═════════════════════════════════════════════════════════════ */}
                {/* ROUTES AVEC LAYOUT PRINCIPAL */} 
                {/* ═════════════════════════════════════════════════════════════ */}
                
                <Route path="/*" element={
                  <MainLayout>
                    <Routes>
                      {/* Page d'accueil */}
                      <Route path="/" element={<HomePage />} />
                      <Route path="/recherche" element={<SearchPage/>} />

                      {/* ═══════════════════════════════════════════════════════ */}
                      {/* ŒUVRES */}
                      {/* ═══════════════════════════════════════════════════════ */}
                      
                      <Route path="/oeuvres" element={<OeuvresPage />} />
                      <Route path="/oeuvres/:id" element={<OeuvreDetail />} />
                      <Route path="/artisanat" element={<ArtisanatPage />} />
                      {/* Routes protégées pour créer/modifier */}
                      <Route 
                      /*  path="/oeuvres/nouvelle" 
                        element={
                          <ProtectedRoute requiresAuth={true}>
                            <OeuvreForm
                              onSubmit={async (data) => {
                                console.log('Nouvelle œuvre :', data);
                                // Appel API via vos hooks
                                window.location.href = '/oeuvres';
                              }}
                              onCancel={() => (window.location.href = '/oeuvres')}
                            />
                          </ProtectedRoute>
                        } */
                      />
                      
                      <Route 
                       /* path="/oeuvres/:id/modifier" 
                        element={
                          <ProtectedRoute requiresAuth={true}>
                            <OeuvreForm
                              isEditing={true}
                              onSubmit={async (data) => {
                                console.log('Œuvre modifiée :', data);
                                // Appel API via vos hooks
                                window.history.back();
                              }}
                              onCancel={() => window.history.back()}
                            />
                          </ProtectedRoute>
                        } */
                      />

                      {/* ═══════════════════════════════════════════════════════ */}
                      {/* ÉVÉNEMENTS */}
                      {/* ═══════════════════════════════════════════════════════ */}
                      
                      <Route path="/evenements" element={<EvenementsPage />} />
                      <Route 
                        path="/evenements/:id" 
                        element={<div className="p-8">Détail événement (à implémenter)</div>} 
                      />
                      
                      <Route 
                       /* path="/evenements/nouveau" 
                        element={
                          <ProtectedRoute requiresAuth={true}>
                            <EvenementForm
                              onSubmit={async (data) => {
                                console.log('Nouvel événement :', data);
                                window.location.href = '/evenements';
                              }}
                              onCancel={() => (window.location.href = '/evenements')}
                            />
                          </ProtectedRoute>
                        } */
                      />

                      {/* ═══════════════════════════════════════════════════════ */}
                      {/* PATRIMOINE */}
                      {/* ═══════════════════════════════════════════════════════ */}
                      
                      <Route path="/patrimoine" element={<PatrimoinePage />} />
                      <Route path="/patrimoine/:id" element={<DetailLieu />} /> 
                      
                      <Route 
                        /*path="/lieux/nouveau" 
                        element={
                          <ProtectedRoute requiresAuth={true}>
                            <LieuForm
                              onSubmit={async (data) => {
                                console.log('Nouveau lieu :', data);
                                window.location.href = '/patrimoine';
                              }}
                              onCancel={() => (window.location.href = '/patrimoine')}
                            />
                          </ProtectedRoute>
                        } */
                      />

                      {/* ═══════════════════════════════════════════════════════ */}
                      {/* COMMUNAUTÉ ET PROFILS */}
                      {/* ═══════════════════════════════════════════════════════ */}
                      
                      <Route 
                        path="/communaute" 
                        element={<div className="p-8">Page communauté (à implémenter)</div>} 
                      />
                      
                      <Route 
                        path="/profil/:id" 
                        element={<div className="p-8">Profil utilisateur (à implémenter)</div>} 
                      />
                      
                      <Route 
                        path="/mon-profil" 
                        element={
                          <ProtectedRoute requiresAuth={true}>
                            <div className="p-8">Mon profil (à implémenter)</div>
                          </ProtectedRoute>
                        } 
                      />

                      {/* ═══════════════════════════════════════════════════════ */}
                      {/* ADMINISTRATION */}
                      {/* ═══════════════════════════════════════════════════════ */}
                      
                     

                      {/* ═══════════════════════════════════════════════════════ */}
                      {/* RECHERCHE */}
                      {/* ═══════════════════════════════════════════════════════ */}
                      
                      <Route 
                        path="/recherche" 
                        element={<div className="p-8">Résultats de recherche (à implémenter)</div>} 
                      />

                      {/* ═══════════════════════════════════════════════════════ */}
                      {/* GALERIE */}
                      {/* ═══════════════════════════════════════════════════════ */}
                      
                      <Route 
                        path="/galerie" 
                        element={<div className="p-8">Galerie média (à implémenter)</div>} 
                      />

                      {/* ═══════════════════════════════════════════════════════ */}
                      {/* PAGES LÉGALES */}
                      {/* ═══════════════════════════════════════════════════════ */}
                      
                      <Route 
                        path="/conditions" 
                        element={<div className="p-8">Conditions d'utilisation (à implémenter)</div>} 
                      />
                      
                      <Route 
                        path="/confidentialite" 
                        element={<div className="p-8">Politique de confidentialité (à implémenter)</div>} 
                      />
                      
                      <Route 
                        path="/mentions-legales" 
                        element={<div className="p-8">Mentions légales (à implémenter)</div>} 
                      />

                      {/* ═══════════════════════════════════════════════════════ */}
                      {/* PAGES D'AIDE */}
                      {/* ═══════════════════════════════════════════════════════ */}
                      
                      <Route 
                        path="/aide" 
                        element={<div className="p-8">Centre d'aide (à implémenter)</div>} 
                      />
                      
                      <Route 
                        path="/contact" 
                        element={<div className="p-8">Contact (à implémenter)</div>} 
                      />

                      {/* ═══════════════════════════════════════════════════════ */}
                      {/* PAGE 404 */}
                      {/* ═══════════════════════════════════════════════════════ */}
                      
                      <Route 
                        path="*" 
                        element={
                          <div className="min-h-screen flex items-center justify-center bg-patrimoine-creme/20">
                            <div className="text-center">
                              <h1 className="text-6xl font-bold text-patrimoine-canard">404</h1>
                              <p className="text-xl text-patrimoine-sombre/70 mt-4">Page non trouvée</p>
                              <p className="text-patrimoine-sombre/60 mt-2">
                                La page que vous recherchez n'existe pas ou a été déplacée.
                              </p>
                              <a
                                href="/"
                                className="mt-6 inline-block btn-patrimoine"
                              >
                                Retour à l'accueil
                              </a>
                            </div>
                          </div>
                        } 
                      />
                    </Routes>
                  </MainLayout>
                } />
              </Routes>
            </div>
          </AuthProvider>
        </NotificationProvider>
      </Router>
    </ErrorBoundary>
  );
};

export default App;
