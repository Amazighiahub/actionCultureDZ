/**
 * FORMULAIRE ADAPTATIF DE CRÉATION D'ŒUVRE
 * 
 * Ce formulaire utilise les hooks suivants de votre application :
 * - useOeuvreForm : Gère la logique du formulaire et la validation
 * - useTagSuggestions : Gère les suggestions intelligentes de tags
 * - useNotifications : Affiche les notifications
 * - useOeuvres : Pour les opérations CRUD
 * 
 * Pour l'utiliser dans votre application :
 * 1. Supprimez la section "Simulation temporaire des hooks"
 * 2. Décommentez les imports des vrais hooks
 * 3. Assurez-vous que tous les services API sont configurés
 */

import React, { useState, useEffect } from 'react';
import {
  Book,
  Newspaper,
  Film,
  Music,
  Camera,
  Box,
  Palette,
  FlaskConical,
  Plus,
  X,
  Info,
  AlertTriangle,
  CheckCircle,
  Tag,
  ArrowLeft,
  ArrowRight,
  Image,
  Trash2,
  Upload,
  Theater,
  Activity,
  Mic,
  Home,
  TrendingUp
} from 'lucide-react';

// Import des hooks existants (à remplacer par les vrais imports)
// import { useOeuvreForm } from '../../hooks/useOeuvreForm';
// import { useTagSuggestions } from '../../hooks/useTagSuggestions';
// import { useNotifications } from '../../hooks/useNotifications';
// import { useOeuvres } from '../../hooks/useOeuvre';

// NOTE: Pour faire fonctionner ce composant dans l'environnement actuel,
// nous devons simuler les hooks. Dans votre application réelle,
// supprimez cette section et décommentez les imports ci-dessus.

// Simulation temporaire des hooks pour la démonstration
const useOeuvreForm = (initialData?: any) => {
  const [values, setValues] = useState<any>({
    titre: initialData?.titre || '',
    description: initialData?.description || '',
    type_oeuvre: '',
    langue: '',
    annee_creation: '',
    categories: [],
    auteurs: [],
    statut: 'brouillon',
    ...initialData
  });
  
  const [errors, setErrors] = useState<any>({});
  const [touched, setTouched] = useState<any>({});
  
  return {
    values,
    errors,
    touched,
    isValid: true,
    isSubmitting: false,
    setValue: (field: string, value: any) => setValues((prev: any) => ({ ...prev, [field]: value })),
    setFieldTouched: (field: string, value: boolean) => setTouched((prev: any) => ({ ...prev, [field]: value })),
    handleSubmit: async (data: any) => { console.log('Soumission:', data); },
    selectedType: values.type_oeuvre === '1' ? 'livre' : 
                  values.type_oeuvre === '2' ? 'film' :
                  values.type_oeuvre === '3' ? 'album' :
                  values.type_oeuvre === '4' ? 'article' :
                  values.type_oeuvre === '5' ? 'article_scientifique' :
                  values.type_oeuvre === '6' ? 'photographie' :
                  values.type_oeuvre === '7' ? 'artisanat' :
                  values.type_oeuvre === '8' ? 'oeuvre_art' : '',
    options: {
      typesOeuvres: [
        { value: '1', label: 'Livre' },
        { value: '2', label: 'Film' },
        { value: '3', label: 'Album Musical' },
        { value: '4', label: 'Article' },
        { value: '5', label: 'Article Scientifique' },
        { value: '6', label: 'Photographie' },
        { value: '7', label: 'Artisanat' },
        { value: '8', label: 'Œuvre d\'Art' }
      ],
      langues: [
        { value: '1', label: 'Tamazight' },
        { value: '2', label: 'Tifinagh' },
        { value: '3', label: 'Arabe' },
        { value: '4', label: 'Derja' },
        { value: '5', label: 'Français' },
        { value: '6', label: 'Anglais' }
      ],
      categories: [
        { value: '1', label: 'Roman' },
        { value: '2', label: 'Poésie' },
        { value: '3', label: 'Documentaire' },
        { value: '4', label: 'Fiction' }
      ],
      auteurs: [
        { value: '1', label: 'Mohamed Dib' },
        { value: '2', label: 'Kateb Yacine' }
      ],
      genres: [
        { value: '1', label: 'Littérature' },
        { value: '2', label: 'Action' }
      ]
    },
    metadata: {
      types_oeuvres: [
        { id_type_oeuvre: 1, nom_type: 'Livre', couleur: '#3B82F6' },
        { id_type_oeuvre: 2, nom_type: 'Film', couleur: '#8B5CF6' }
      ]
    },
    shouldShowField: (field: string) => {
      const typeFields: any = {
        'livre': ['isbn', 'nb_pages', 'editeur_original', 'traduction'],
        'film': ['duree_minutes', 'realisateur', 'budget', 'classification'],
        'album': ['duree', 'label', 'nombre_pistes', 'id_genre'],
        'article': ['source', 'type_article', 'niveau_credibilite'],
        'article_scientifique': ['journal', 'doi', 'peer_reviewed'],
        'photographie': ['technique', 'appareil', 'lieu_prise'],
        'artisanat': ['dimensions', 'poids', 'region_origine'],
        'oeuvre_art': ['technique', 'dimensions', 'support', 'style_artistique']
      };
      const selectedType = values.type_oeuvre === '1' ? 'livre' : 
                          values.type_oeuvre === '2' ? 'film' :
                          values.type_oeuvre === '3' ? 'album' :
                          values.type_oeuvre === '4' ? 'article' :
                          values.type_oeuvre === '5' ? 'article_scientifique' :
                          values.type_oeuvre === '6' ? 'photographie' :
                          values.type_oeuvre === '7' ? 'artisanat' :
                          values.type_oeuvre === '8' ? 'oeuvre_art' : '';
      return typeFields[selectedType]?.includes(field) || false;
    },
    getSelectedTypeInfo: () => {
      const typeMap: any = {
        '1': 'Livre',
        '2': 'Film',
        '3': 'Album Musical',
        '4': 'Article',
        '5': 'Article Scientifique',
        '6': 'Photographie',
        '7': 'Artisanat',
        '8': 'Œuvre d\'Art'
      };
      return values.type_oeuvre ? 
        { value: values.type_oeuvre, label: typeMap[values.type_oeuvre] || '' } : 
        null;
    }
  };
};

const useTagSuggestions = (options: any) => {
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [newTagInput, setNewTagInput] = useState('');
  
  return {
    selectedTags,
    newTagInput,
    setNewTagInput,
    isCreatingTag: false,
    addFromInput: () => {
      if (newTagInput.trim() && !selectedTags.includes(newTagInput.trim())) {
        setSelectedTags([...selectedTags, newTagInput.trim()]);
        setNewTagInput('');
      }
    },
    addSuggestion: (tag: any) => {
      if (!selectedTags.includes(tag.nom)) {
        setSelectedTags([...selectedTags, tag.nom]);
      }
    },
    removeTag: (tag: string) => {
      setSelectedTags(selectedTags.filter((t: string) => t !== tag));
    },
    suggestions: [
      { id_tag: 1, nom: 'patrimoine', source: 'popular' },
      { id_tag: 2, nom: 'culture', source: 'ai' },
      { id_tag: 3, nom: 'traditionnel', source: 'popular' }
    ]
  };
};

const useNotifications = () => ({
  addNotification: (notification: any) => {
    console.log('Notification:', notification);
  }
});

const useOeuvres = () => ({
  getOeuvre: async (id: number) => null,
  loading: false
});

// Import des types
import type { CreateOeuvreData, Oeuvre } from '../../types/oeuvre';
import type { TypeOeuvre } from '../../types/classification';

// Mapping des icônes pour les types d'œuvres
const typeIcons: Record<string, any> = {
  'Livre': Book,
  'Film': Film,
  'Album Musical': Music,
  'Article': Newspaper,
  'Article Scientifique': FlaskConical,
  'Artisanat': Box,
  'Œuvre d\'Art': Palette,
  'Photographie': Camera,
  'Théâtre': Theater,
  'Danse': Activity,
  'Performance': Mic,
  'Installation': Home
};

interface AdaptiveOeuvreFormProps {
  initialData?: Partial<CreateOeuvreData>;
  onSuccess?: () => void;
  onCancel?: () => void;
}

const AdaptiveOeuvreForm: React.FC<AdaptiveOeuvreFormProps> = ({
  initialData,
  onSuccess,
  onCancel
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const { addNotification } = useNotifications();
  
  // Utilisation du hook useOeuvreForm
  const {
    values,
    errors,
    touched,
    isValid,
    isSubmitting,
    setValue,
    setFieldTouched,
    handleSubmit,
    selectedType,
    options,
    metadata,
    shouldShowField,
    getSelectedTypeInfo
  } = useOeuvreForm(initialData);

  // Hook pour les suggestions de tags
  const tagSuggestions = useTagSuggestions({
    typeOeuvre: getSelectedTypeInfo()?.label,
    categories: values.categories?.map((id: string) => 
      options.categories?.find((c: any) => c.value === id)?.label || ''
    ),
    langue: options.langues?.find((l: any) => l.value === values.langue)?.label,
    titre: values.titre,
    description: values.description
  });langues?.find(l => l.value === values.langue)?.label,
    titre: values.titre,
    description: values.description
  });

  // État pour les médias
  const [uploadedMedia, setUploadedMedia] = useState<string[]>(initialData?.images || []);

  // Configuration des médias requis par type
  const mediaRequirements: Record<string, { required: boolean; types: string[] }> = {
    'Film': { required: true, types: ['video', 'image'] },
    'Album Musical': { required: true, types: ['audio', 'image'] },
    'Photographie': { required: true, types: ['image'] },
    'Artisanat': { required: true, types: ['image'] },
    'Œuvre d\'Art': { required: true, types: ['image'] }
  };

  // Gestion de la soumission
  const onFormSubmit = async (formData: CreateOeuvreData) => {
    try {
      // Vérification des médias requis
      const typeInfo = getSelectedTypeInfo();
      const requirement = typeInfo ? mediaRequirements[typeInfo.label] : null;
      
      if (requirement?.required && uploadedMedia.length === 0) {
        addNotification({
          type: 'error',
          title: 'Médias requis',
          message: `Au moins un média est requis pour ce type d'œuvre`
        });
        return;
      }

      // Préparer les données complètes
      const dataToSubmit = {
        ...formData,
        images: uploadedMedia,
        tags: tagSuggestions.selectedTags
      };

      // La soumission est gérée par le hook
      await handleSubmit(dataToSubmit);
      
      addNotification({
        type: 'success',
        title: 'Succès',
        message: initialData ? 'Œuvre modifiée avec succès' : 'Œuvre créée avec succès'
      });
      
      if (onSuccess) onSuccess();
    } catch (error) {
      console.error('Erreur soumission:', error);
    }
  };

  // Navigation entre étapes
  const canGoNext = () => {
    switch (currentStep) {
      case 1:
        return values.titre && values.type_oeuvre && values.description;
      case 2:
        return values.categories?.length > 0 && values.auteurs?.length > 0;
      case 3:
        const requirement = getSelectedTypeInfo() ? 
          mediaRequirements[getSelectedTypeInfo()!.label] : null;
        return !requirement?.required || uploadedMedia.length > 0;
      default:
        return true;
    }
  };

  // Rendu des champs spécifiques selon le type
  const renderSpecificFields = () => {
    if (!selectedType) return null;

    const fields = [];
    
    // Champs spécifiques pour Livre
    if (selectedType === 'livre' && shouldShowField('isbn')) {
      fields.push(
        <div key="isbn">
          <label className="block text-sm font-medium mb-2">ISBN</label>
          <input
            type="text"
            value={values.isbn || ''}
            onChange={(e) => setValue('isbn', e.target.value)}
            onBlur={() => setFieldTouched('isbn', true)}
            placeholder="978-0-123456-78-9"
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {touched.isbn && errors.isbn && (
            <p className="mt-1 text-sm text-red-500">{errors.isbn}</p>
          )}
        </div>
      );
    }

    if (selectedType === 'livre' && shouldShowField('nb_pages')) {
      fields.push(
        <div key="nb_pages">
          <label className="block text-sm font-medium mb-2">Nombre de pages</label>
          <input
            type="number"
            value={values.nb_pages || ''}
            onChange={(e) => setValue('nb_pages', e.target.value)}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      );
    }

    // Champs spécifiques pour Film
    if (selectedType === 'film' && shouldShowField('duree_minutes')) {
      fields.push(
        <div key="duree_minutes">
          <label className="block text-sm font-medium mb-2">
            Durée (minutes) <span className="text-red-500">*</span>
          </label>
          <input
            type="number"
            value={values.duree_minutes || ''}
            onChange={(e) => setValue('duree_minutes', e.target.value)}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      );
    }

    if (selectedType === 'film' && shouldShowField('realisateur')) {
      fields.push(
        <div key="realisateur">
          <label className="block text-sm font-medium mb-2">
            Réalisateur <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={values.realisateur || ''}
            onChange={(e) => setValue('realisateur', e.target.value)}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      );
    }

    // Ajouter d'autres champs selon les types...
    
    return fields;
  };

  if (!metadata || !options) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p>Chargement des métadonnées...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        
        {/* En-tête */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            {initialData ? 'Modifier l\'œuvre' : 'Créer une nouvelle œuvre'}
          </h1>
          <p className="mt-2 text-gray-600">
            Partagez votre création culturelle avec la communauté
          </p>
        </div>

        {/* Indicateur d'étapes */}
        <div className="mb-8">
          <div className="flex items-center justify-center">
            {[
              { step: 1, label: 'Informations de base' },
              { step: 2, label: 'Détails et catégories' },
              { step: 3, label: 'Médias' },
              { step: 4, label: 'Publication' }
            ].map((item, index) => (
              <React.Fragment key={item.step}>
                <div className={`flex items-center ${index > 0 ? 'ml-4' : ''}`}>
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium ${
                      currentStep >= item.step
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {currentStep > item.step ? <CheckCircle size={20} /> : item.step}
                  </div>
                  <span className="ml-2 text-sm font-medium text-gray-900 hidden sm:block">
                    {item.label}
                  </span>
                </div>
                {index < 3 && (
                  <div
                    className={`w-12 h-1 mx-2 ${
                      currentStep > item.step ? 'bg-blue-600' : 'bg-gray-200'
                    }`}
                  />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Formulaire */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          
          {/* Étape 1: Informations de base */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold mb-6">Informations de base</h2>

              {/* Type d'œuvre */}
              <div>
                <label className="block text-sm font-medium mb-3">
                  Type d'œuvre <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {options.typesOeuvres?.map((type) => {
                    const Icon = typeIcons[type.label] || Book;
                    const typeData = metadata?.types_oeuvres?.find(
                      t => t.id_type_oeuvre.toString() === type.value
                    );
                    
                    return (
                      <label
                        key={type.value}
                        className={`relative flex flex-col items-center cursor-pointer rounded-lg border-2 p-4 transition-all ${
                          values.type_oeuvre === type.value
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <input
                          type="radio"
                          name="type_oeuvre"
                          value={type.value}
                          checked={values.type_oeuvre === type.value}
                          onChange={(e) => setValue('type_oeuvre', e.target.value)}
                          className="sr-only"
                        />
                        <Icon
                          size={32}
                          className={`mb-2 ${
                            values.type_oeuvre === type.value 
                              ? 'text-blue-600' 
                              : 'text-gray-400'
                          }`}
                          style={{ 
                            color: values.type_oeuvre === type.value && typeData?.couleur 
                              ? typeData.couleur 
                              : undefined 
                          }}
                        />
                        <span className="text-sm font-medium text-center">
                          {type.label}
                        </span>
                      </label>
                    );
                  })}
                </div>
                {touched.type_oeuvre && errors.type_oeuvre && (
                  <p className="mt-2 text-sm text-red-500">{errors.type_oeuvre}</p>
                )}
              </div>

              {/* Titre */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Titre de l'œuvre <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={values.titre || ''}
                  onChange={(e) => setValue('titre', e.target.value)}
                  onBlur={() => setFieldTouched('titre', true)}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Entrez le titre de votre œuvre"
                />
                {touched.titre && errors.titre && (
                  <p className="mt-1 text-sm text-red-500">{errors.titre}</p>
                )}
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={values.description || ''}
                  onChange={(e) => setValue('description', e.target.value)}
                  onBlur={() => setFieldTouched('description', true)}
                  rows={4}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Décrivez votre œuvre..."
                />
                {touched.description && errors.description && (
                  <p className="mt-1 text-sm text-red-500">{errors.description}</p>
                )}
              </div>

              {/* Langue */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Langue <span className="text-red-500">*</span>
                </label>
                <select
                  value={values.langue || ''}
                  onChange={(e) => setValue('langue', e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Sélectionner une langue</option>
                  {options.langues?.map(langue => (
                    <option key={langue.value} value={langue.value}>
                      {langue.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Année de création */}
              <div>
                <label className="block text-sm font-medium mb-2">Année de création</label>
                <input
                  type="number"
                  value={values.annee_creation || ''}
                  onChange={(e) => setValue('annee_creation', e.target.value)}
                  onBlur={() => setFieldTouched('annee_creation', true)}
                  min="1000"
                  max={new Date().getFullYear()}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Ex: 2023"
                />
                {touched.annee_creation && errors.annee_creation && (
                  <p className="mt-1 text-sm text-red-500">{errors.annee_creation}</p>
                )}
              </div>
            </div>
          )}

          {/* Étape 2: Détails et catégories */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold mb-6">
                Détails et catégories
                {getSelectedTypeInfo() && (
                  <span className="ml-2 text-sm font-normal text-blue-600">
                    ({getSelectedTypeInfo()!.label})
                  </span>
                )}
              </h2>

              {/* Champs spécifiques au type */}
              {selectedType && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {renderSpecificFields()}
                </div>
              )}

              {/* Genre (si applicable) */}
              {shouldShowField('id_genre') && options.genres && (
                <div>
                  <label className="block text-sm font-medium mb-2">Genre</label>
                  <select
                    value={values.id_genre || ''}
                    onChange={(e) => setValue('id_genre', e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Sélectionner un genre</option>
                    {options.genres.map(genre => (
                      <option key={genre.value} value={genre.value}>
                        {genre.label}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Auteurs */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Auteurs/Créateurs <span className="text-red-500">*</span>
                </label>
                <select
                  onChange={(e) => {
                    const value = e.target.value;
                    if (value && !values.auteurs?.includes(value)) {
                      setValue('auteurs', [...(values.auteurs || []), value]);
                    }
                  }}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Ajouter un auteur...</option>
                  {options.auteurs?.map(auteur => (
                    <option
                      key={auteur.value}
                      value={auteur.value}
                      disabled={values.auteurs?.includes(auteur.value)}
                    >
                      {auteur.label}
                    </option>
                  ))}
                </select>
                {values.auteurs && values.auteurs.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-2">
                    {values.auteurs.map(auteurId => {
                      const auteur = options.auteurs?.find(a => a.value === auteurId);
                      return (
                        <span
                          key={auteurId}
                          className="inline-flex items-center px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm"
                        >
                          {auteur?.label || auteurId}
                          <button
                            type="button"
                            onClick={() => setValue('auteurs', values.auteurs?.filter((id: string) => id !== auteurId) || [])}
                            className="ml-2 text-green-600 hover:text-green-800"
                          >
                            <X size={14} />
                          </button>
                        </span>
                      );
                    })}
                  </div>
                )}
                {touched.auteurs && errors.auteurs && (
                  <p className="mt-1 text-sm text-red-500">{errors.auteurs}</p>
                )}
              </div>

              {/* Catégories */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Catégories <span className="text-red-500">*</span>
                </label>
                <select
                  onChange={(e) => {
                    const value = e.target.value;
                    if (value && !values.categories?.includes(value)) {
                      setValue('categories', [...(values.categories || []), value]);
                    }
                  }}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Ajouter une catégorie...</option>
                  {options.categories?.map(cat => (
                    <option
                      key={cat.value}
                      value={cat.value}
                      disabled={values.categories?.includes(cat.value)}
                    >
                      {cat.label}
                    </option>
                  ))}
                </select>
                {values.categories && values.categories.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-2">
                    {values.categories.map(catId => {
                      const cat = options.categories?.find(c => c.value === catId);
                      return (
                        <span
                          key={catId}
                          className="inline-flex items-center px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm"
                        >
                          {cat?.label || catId}
                          <button
                            type="button"
                            onClick={() => setValue('categories', values.categories?.filter((id: string) => id !== catId) || [])}
                            className="ml-2 text-purple-600 hover:text-purple-800"
                          >
                            <X size={14} />
                          </button>
                        </span>
                      );
                    })}
                  </div>
                )}
                {touched.categories && errors.categories && (
                  <p className="mt-1 text-sm text-red-500">{errors.categories}</p>
                )}
              </div>

              {/* Tags avec suggestions intelligentes */}
              <div>
                <label className="block text-sm font-medium mb-2">Tags (mots-clés)</label>
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={tagSuggestions.newTagInput}
                      onChange={(e) => tagSuggestions.setNewTagInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          tagSuggestions.addFromInput();
                        }
                      }}
                      placeholder="Ajouter un tag..."
                      className="flex-1 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button
                      type="button"
                      onClick={tagSuggestions.addFromInput}
                      disabled={tagSuggestions.isCreatingTag}
                      className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50"
                    >
                      {tagSuggestions.isCreatingTag ? (
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white" />
                      ) : (
                        <Plus size={20} />
                      )}
                    </button>
                  </div>

                  {/* Tags sélectionnés */}
                  {tagSuggestions.selectedTags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {tagSuggestions.selectedTags.map(tag => (
                        <span key={tag} className="inline-flex items-center px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                          #{tag}
                          <button
                            type="button"
                            onClick={() => tagSuggestions.removeTag(tag)}
                            className="ml-2 text-blue-600 hover:text-blue-800"
                          >
                            <X size={14} />
                          </button>
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Suggestions */}
                  {tagSuggestions.suggestions.length > 0 && (
                    <div>
                      <p className="text-sm text-gray-600 mb-2">Suggestions :</p>
                      <div className="flex flex-wrap gap-2">
                        {tagSuggestions.suggestions.slice(0, 8).map((suggestion: any) => (
                          <button
                            key={suggestion.id_tag}
                            type="button"
                            onClick={() => tagSuggestions.addSuggestion(suggestion)}
                            className="px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-full flex items-center gap-1"
                          >
                            {suggestion.source === 'ai' && <FlaskConical size={12} />}
                            {suggestion.source === 'popular' && <TrendingUp size={12} />}
                            #{suggestion.nom}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Étape 3: Médias */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold mb-6">
                Médias et fichiers
                {getSelectedTypeInfo() && mediaRequirements[getSelectedTypeInfo()!.label]?.required && (
                  <span className="ml-2 text-sm font-normal text-red-600">
                    (requis pour ce type d'œuvre)
                  </span>
                )}
              </h2>

              {getSelectedTypeInfo() && (
                <>
                  {/* Info sur les types de médias acceptés */}
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-start">
                      <Info className="text-blue-600 mt-0.5 mr-3" size={20} />
                      <div>
                        <h4 className="font-medium text-blue-900">
                          Types de médias acceptés pour {getSelectedTypeInfo()!.label}
                        </h4>
                        <ul className="text-sm text-blue-700 mt-1">
                          {mediaRequirements[getSelectedTypeInfo()!.label]?.types.map(type => (
                            <li key={type}>
                              • {type === 'image' ? 'Images (JPEG, PNG, WebP)' :
                                 type === 'video' ? 'Vidéos (MP4, WebM)' :
                                 type === 'audio' ? 'Audio (MP3, WAV, OGG)' :
                                 'Documents (PDF, DOCX)'}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>

                  {/* Zone d'upload */}
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Upload size={48} className="mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-600 mb-2">
                      Glissez-déposez vos fichiers ici ou cliquez pour parcourir
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        // Simuler l'ajout d'un média
                        const newMedia = `media-${Date.now()}.jpg`;
                        setUploadedMedia([...uploadedMedia, newMedia]);
                      }}
                      className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                    >
                      Ajouter un fichier
                    </button>
                  </div>

                  {/* Aperçu des médias */}
                  {uploadedMedia.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-3">
                        Fichiers ajoutés ({uploadedMedia.length})
                      </h4>
                      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {uploadedMedia.map((media, index) => (
                          <div key={index} className="relative group">
                            <div className="w-full h-24 bg-gray-200 rounded-lg flex items-center justify-center">
                              <Image size={32} className="text-gray-400" />
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                setUploadedMedia(uploadedMedia.filter((_, i: number) => i !== index));
                              }}
                              className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <Trash2 size={12} />
                            </button>
                            <p className="text-xs text-center mt-1 truncate">{media}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {/* Étape 4: Publication */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold mb-6">Options de publication</h2>

              {/* Statut de publication */}
              <div>
                <label className="block text-sm font-medium mb-3">Statut de publication</label>
                <div className="space-y-3">
                  {[
                    {
                      value: 'brouillon',
                      label: 'Brouillon',
                      description: 'Sauvegarde privée, non visible publiquement'
                    },
                    {
                      value: 'en_attente',
                      label: 'En attente de validation',
                      description: 'Soumis pour validation par les modérateurs'
                    }
                  ].map(status => (
                    <label
                      key={status.value}
                      className={`flex items-start space-x-3 p-4 border rounded-lg cursor-pointer transition-all ${
                        values.statut === status.value
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <input
                        type="radio"
                        name="statut"
                        value={status.value}
                        checked={values.statut === status.value}
                        onChange={(e) => setValue('statut', e.target.value)}
                        className="mt-1"
                      />
                      <div>
                        <div className="font-medium">{status.label}</div>
                        <div className="text-sm text-gray-600">{status.description}</div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Résumé */}
              <div className="bg-gray-50 rounded-lg p-6">
                <h4 className="font-semibold mb-4">Résumé de votre œuvre</h4>
                <div className="space-y-2 text-sm">
                  <div>
                    <span className="font-medium">Titre :</span> {values.titre || 'Non défini'}
                  </div>
                  <div>
                    <span className="font-medium">Type :</span> {getSelectedTypeInfo()?.label || 'Non défini'}
                  </div>
                  <div>
                    <span className="font-medium">Langue :</span>{' '}
                    {options.langues?.find(l => l.value === values.langue)?.label || 'Non définie'}
                  </div>
                  <div>
                    <span className="font-medium">Catégories :</span> {values.categories?.length || 0} sélectionnée(s)
                  </div>
                  <div>
                    <span className="font-medium">Tags :</span> {tagSuggestions.selectedTags.length} ajouté(s)
                  </div>
                  <div>
                    <span className="font-medium">Médias :</span> {uploadedMedia.length} fichier(s)
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between pt-8 mt-8 border-t">
            <div className="flex space-x-3">
              <button
                type="button"
                onClick={onCancel}
                className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Annuler
              </button>

              {currentStep > 1 && (
                <button
                  type="button"
                  onClick={() => setCurrentStep(prev => prev - 1)}
                  className="flex items-center px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  <ArrowLeft size={16} className="mr-1" />
                  Précédent
                </button>
              )}
            </div>

            <div className="flex space-x-3">
              {currentStep < 4 ? (
                <button
                  type="button"
                  onClick={() => setCurrentStep(prev => prev + 1)}
                  disabled={!canGoNext()}
                  className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Suivant
                  <ArrowRight size={16} className="ml-1" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => onFormSubmit(values as CreateOeuvreData)}
                  disabled={isSubmitting || !isValid}
                  className="flex items-center px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Création en cours...
                    </>
                  ) : (
                    <>
                      <CheckCircle size={16} className="mr-1" />
                      {initialData ? 'Modifier l\'œuvre' : 'Créer l\'œuvre'}
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Exemple d'utilisation avec les vrais hooks
const ExampleUsage = () => {
  // Dans votre app, utilisez : const navigate = useNavigate();
  
  return (
    <AdaptiveOeuvreForm
      onSuccess={() => {
        // Rediriger après création
        // navigate('/mes-oeuvres');
        console.log('Redirection vers /mes-oeuvres');
      }}
      onCancel={() => {
        // Retour à la liste
        // navigate(-1);
        console.log('Retour à la page précédente');
      }}
    />
  );
};

// Pour l'édition d'une œuvre existante
const EditOeuvreExample = ({ oeuvreId }: { oeuvreId: number }) => {
  const { getOeuvre } = useOeuvres();
  const [oeuvre, setOeuvre] = useState<Oeuvre | null>(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const loadOeuvre = async () => {
      const data = await getOeuvre(oeuvreId);
      setOeuvre(data);
      setLoading(false);
    };
    loadOeuvre();
  }, [oeuvreId]);
  
  if (loading) {
    return <div>Chargement...</div>;
  }
  
  return (
    <AdaptiveOeuvreForm
      initialData={oeuvre || undefined}
      onSuccess={() => {
        window.location.href = `/oeuvre/${oeuvreId}`;
      }}
      onCancel={() => {
        window.history.back();
      }}
    />
  );
};

