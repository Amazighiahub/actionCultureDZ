/ src/hooks/useFormPersistence.ts - Hook pour sauvegarder les formulaires
import { useEffect } from 'react';
import { useLocalStorage } from './useLocalStorage';

export const useFormPersistence = <T extends Record<string, any>>(
  key: string,
  values: T,
  enabled: boolean = true
) => {
  const [savedValues, setSavedValues] = useLocalStorage<T | null>(`form_${key}`, null);

  // Sauvegarder les valeurs quand elles changent
  useEffect(() => {
    if (enabled && values) {
      setSavedValues(values);
    }
  }, [values, enabled, setSavedValues]);

  // Nettoyer la sauvegarde
  const clearSaved = () => {
    setSavedValues(null);
  };

  return {
    savedValues,
    clearSaved,
    hasSavedValues: savedValues !== null
  };
};
