// src/hooks/useAuth.tsx

import React, {
  useState,
  useEffect,
  useCallback,
  createContext,
  useContext,
  ReactNode
} from 'react';
import { useNotifications } from '../components/UI';
import type {
  User,
  LoginCredentials,
  RegisterData,
  AuthResponse,
  AuthState,
  ChangePasswordData,
  UpdateProfileData
} from '../types/user';
import { authService } from '../services/api/auth';

// ─── 1) Définition du type du contexte d’authentification ─────────────────────

export interface AuthContextType extends Omit<AuthState, 'token'> {
  // On retire 'token' de AuthState pour ne pas accéder au client privé
  login: (credentials: LoginCredentials) => Promise<User>;
  register: (data: RegisterData) => Promise<User>;
  logout: () => void;
  updateProfile: (data: UpdateProfileData) => Promise<User>;
  changePassword: (data: ChangePasswordData) => Promise<void>;
  refreshUser: () => Promise<void>;

  canCreateOeuvre: boolean;
  canCreateEvenement: boolean;
  canValidateContent: boolean;
  canModerate: boolean;
  isAuthenticated: boolean;
}

// ─── 2) Création du Context (non exporté) ────────────────────────────────────

const AuthContext = createContext<AuthContextType | null>(null);

// ─── 3) Hook pour consommer le contexte ──────────────────────────────────────

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// ─── 4) Provider d’authentification ──────────────────────────────────────────

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // On supprime “token” de l’état, car on ne l’expose plus directement
  const [authState, setAuthState] = useState<Omit<AuthState, 'token'>>({
    isAuthenticated: false,
    user: null,
    // token retiré
    isLoading: true,
    error: null
  });
  const { addNotification } = useNotifications();

  // 4.1 – Au montage, on vérifie si un token valide existe via authService.checkAuthStatus()
  useEffect(() => {
    const initAuth = async () => {
      try {
        const user = await authService.checkAuthStatus();
        if (user) {
          setAuthState({
            isAuthenticated: true,
            user,
            isLoading: false,
            error: null
          });
          return;
        }
      } catch (e) {
        console.error('Erreur lors de la vérification du token :', e);
        authService.logout();
      }
      setAuthState({
        isAuthenticated: false,
        user: null,
        isLoading: false,
        error: null
      });
    };
    initAuth();
  }, []);

  // 4.2 – Fonction “login”
  const login = useCallback(
    async (credentials: LoginCredentials): Promise<User> => {
      try {
        setAuthState(prev => ({ ...prev, isLoading: true, error: null }));
        const data: AuthResponse = await authService.login(credentials);
        // authService.login() a stocké le token dans apiClient
        const userProfile: User = await authService.getProfile();
        setAuthState({
          isAuthenticated: true,
          user: userProfile,
          isLoading: false,
          error: null
        });
        addNotification({
          type: 'success',
          title: 'Connexion réussie',
          message: `Bienvenue ${userProfile.prenom} !`
        });
        return userProfile;
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Erreur de connexion';
        setAuthState(prev => ({ ...prev, isLoading: false, error: message }));
        addNotification({
          type: 'error',
          title: 'Erreur de connexion',
          message
        });
        throw error;
      }
    },
    [addNotification]
  );

  // 4.3 – Fonction “register”
  const register = useCallback(
    async (data: RegisterData): Promise<User> => {
      try {
        setAuthState(prev => ({ ...prev, isLoading: true, error: null }));
        const response: AuthResponse = await authService.register(data);
        // authService.register() a stocké le token dans apiClient
        const userProfile: User = await authService.getProfile();
        setAuthState({
          isAuthenticated: true,
          user: userProfile,
          isLoading: false,
          error: null
        });
        addNotification({
          type: 'success',
          title: 'Inscription réussie',
          message: `Bienvenue ${userProfile.prenom} ! Votre compte a été créé.`
        });
        return userProfile;
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Erreur d\'inscription';
        setAuthState(prev => ({ ...prev, isLoading: false, error: message }));
        addNotification({
          type: 'error',
          title: 'Erreur d\'inscription',
          message
        });
        throw error;
      }
    },
    [addNotification]
  );

  // 4.4 – Fonction “logout”
  const logout = useCallback(() => {
    authService.logout(); // vide le token & cache dans apiClient
    setAuthState({
      isAuthenticated: false,
      user: null,
      isLoading: false,
      error: null
    });
    addNotification({
      type: 'info',
      title: 'Déconnexion',
      message: 'Vous avez été déconnecté avec succès'
    });
    window.location.href = '/';
  }, [addNotification]);

  // 4.5 – Fonction “updateProfile”
  const updateProfile = useCallback(
    async (profileData: UpdateProfileData): Promise<User> => {
      // On ne vérifie plus “authState.token” : si on arrivait ici, c’est que isAuthenticated=true
      try {
        const updated: User = await authService.updateProfile(profileData);
        setAuthState(prev => ({ ...prev, user: updated }));
        addNotification({
          type: 'success',
          title: 'Profil mis à jour',
          message: 'Vos informations ont été sauvegardées'
        });
        return updated;
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Erreur de mise à jour';
        addNotification({
          type: 'error',
          title: 'Erreur de profil',
          message
        });
        throw error;
      }
    },
    [addNotification]
  );

  // 4.6 – Fonction “changePassword”
  const changePassword = useCallback(
    async (passwordData: ChangePasswordData): Promise<void> => {
      try {
        await authService.changePassword(passwordData);
        addNotification({
          type: 'success',
          title: 'Mot de passe changé',
          message: 'Votre mot de passe a été mis à jour avec succès'
        });
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Erreur de mot de passe';
        addNotification({
          type: 'error',
          title: 'Erreur',
          message
        });
        throw error;
      }
    },
    [addNotification]
  );

  // 4.7 – Fonction “refreshUser”
  const refreshUser = useCallback(async (): Promise<void> => {
    try {
      const fresh: User = await authService.getProfile();
      setAuthState(prev => ({ ...prev, user: fresh }));
    } catch (error) {
      console.error('Erreur lors de l’actualisation du profil :', error);
    }
  }, []);

  // ───── 5) Calcul des permissions métiers ────────────────────────────────────

  const canCreateOeuvre = authState.user
    ? authService.canCreateOeuvre(authState.user)
    : false;
  const canCreateEvenement = authState.user
    ? authService.canCreateEvenement(authState.user)
    : false;
  const canValidateContent = authState.user
    ? authService.canModerate(authState.user)
    : false;
  const canModerate = authState.user
    ? authService.canModerate(authState.user)
    : false;

  // ───── 6) Valeur finale du contexte ────────────────────────────────────────

  const contextValue: AuthContextType = {
    isAuthenticated: authState.isAuthenticated,
    user: authState.user,
    isLoading: authState.isLoading,
    error: authState.error,
    login,
    register,
    logout,
    updateProfile,
    changePassword,
    refreshUser,
    canCreateOeuvre,
    canCreateEvenement,
    canValidateContent,
    canModerate
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};
