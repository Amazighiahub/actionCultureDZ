// src/config/api.ts - Configuration de l'API CORRIGÉE

// =============================================================================
// CONFIGURATION DE BASE
// =============================================================================

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  pagination?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// ✅ CORRIGÉ : PaginatedResponse avec structure data
export interface PaginatedResponse<T> {
  data: {
    items: T[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number; // ✅ CORRIGÉ : 'pages' au lieu de 'totalPages' pour correspondre au code
    };
  };
}

// ✅ AJOUT : Interface pour la pagination seule
export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  pages: number;
}

// ✅ AJOUT : Interface pour les erreurs de validation
export interface ValidationError {
  field: string;
  message: string;
}

// Configuration API selon l'environnement
export const API_CONFIG = {
  // Si on utilise le proxy Vite en dev, on peut utiliser des URLs relatives

  // ✅ CORRIGÉ : Ajouter /api au BASE_URL
  BASE_URL: import.meta.env.VITE_API_URL || 'http://localhost:3001/api',
  UPLOAD_URL: import.meta.env.VITE_UPLOAD_URL || (import.meta.env.DEV ? '/uploads' : 'http://localhost:3001/uploads'),
  // ... reste de la configuration

  TIMEOUT: 30000, // 30 secondes
  RETRY_ATTEMPTS: 3,
  RETRY_DELAY: 1000, // 1 seconde
  
  // Configuration du cache
  CACHE_TTL: 5 * 60 * 1000, // 5 minutes
  
  // Clé de stockage du token
  TOKEN_KEY: 'actionculture_token',
  USER_KEY: 'actionculture_user',
  
  // Headers par défaut
  DEFAULT_HEADERS: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  }
};

// Types d'erreurs API
export enum ApiErrorType {
  NETWORK = 'NETWORK_ERROR',
  TIMEOUT = 'TIMEOUT_ERROR',
  UNAUTHORIZED = 'UNAUTHORIZED',
  FORBIDDEN = 'FORBIDDEN',
  NOT_FOUND = 'NOT_FOUND',
  VALIDATION = 'VALIDATION_ERROR',
  SERVER = 'SERVER_ERROR',
  UNKNOWN = 'UNKNOWN_ERROR'
}

export class ApiError extends Error {
  constructor(
    public type: ApiErrorType,
    public message: string,
    public details?: any
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

// Helper pour construire les URLs
export const buildUrl = (path: string): string => {
  // Si on est en dev et que l'URL commence par /api, on utilise directement le path
  if (import.meta.env.DEV && path.startsWith('/')) {
    return path;
  }
  
  const baseUrl = API_CONFIG.BASE_URL.replace(/\/$/, '');
  const cleanPath = path.replace(/^\//, '');
  return `${baseUrl}/${cleanPath}`;
};

// Helper pour construire les URLs d'upload
export const buildUploadUrl = (filename: string): string => {
  const baseUrl = API_CONFIG.UPLOAD_URL.replace(/\/$/, '');
  return `${baseUrl}/${filename}`;
};

// Log de la configuration en développement
if (import.meta.env.DEV) {
  console.log('📡 Configuration API:', {
    BASE_URL: API_CONFIG.BASE_URL,
    UPLOAD_URL: API_CONFIG.UPLOAD_URL,
    Environment: import.meta.env.MODE
  });
}

export const API_ENDPOINTS = {
  // Authentification

  // ✅ CORRIGÉ - Authentification (utilise /users/ au lieu de /auth/)
  AUTH: {
    LOGIN: '/users/login',           // ✅ CORRIGÉ : /users/login au lieu de /auth/login
    REGISTER: '/users/register',     // ✅ CORRIGÉ : /users/register au lieu de /auth/register
    LOGOUT: '/users/logout',         // ✅ CORRIGÉ : /users/logout au lieu de /auth/logout
    PROFILE: '/users/profile',       // ✅ CORRIGÉ : /users/profile au lieu de /auth/profile
    CHANGE_PASSWORD: '/users/change-password', // ✅ CORRIGÉ : /users/change-password
    REFRESH_TOKEN: '/users/refresh', // ✅ CORRIGÉ : /users/refresh
  },

  // Œuvres
  OEUVRES: {
    BASE: '/oeuvres',
    BY_ID: (id: number) => `/oeuvres/${id}`,
    BY_USER: (userId: number) => `/oeuvres/user/${userId}`,
    SEARCH: '/oeuvres/search',
    VALIDATE: (id: number) => `/oeuvres/${id}/validate`,
    STATISTICS: '/oeuvres/statistics',
    RECENT: '/oeuvres/recent',
    POPULAR: '/oeuvres/popular',
    BY_TYPE: (type: string) => `/oeuvres/by-type/${type}`,
    MY_OEUVRES: '/oeuvres/my-oeuvres',
    CHECK_TITLE: '/oeuvres/check-title',
    SUGGESTIONS: '/oeuvres/suggestions',
  },

  // Événements
  EVENEMENTS: {
    BASE: '/evenements',
    BY_ID: (id: number) => `/evenements/${id}`,
    UPCOMING: '/evenements/upcoming',
    INSCRIPTION: (id: number) => `/evenements/${id}/inscription`,
    PARTICIPANTS: (id: number) => `/evenements/${id}/participants`,
    MY_EVENTS: '/evenements/my-events',
    MY_INSCRIPTIONS: '/evenements/my-inscriptions',
    BY_USER: (userId: number) => `/evenements/user/${userId}`,
    BY_LIEU: (lieuId: number) => `/evenements/lieu/${lieuId}`,
    SEARCH: '/evenements/search',
    POPULAR: '/evenements/popular',
    STATISTICS: '/evenements/statistics',
    CHECK_NAME: '/evenements/check-name',
    SUGGESTIONS: '/evenements/suggestions',
    EXPORT_PARTICIPANTS: (id: number) => `/evenements/${id}/participants/export`,
  },

  // ✅ PATRIMOINE - CORRIGÉ avec endpoint PROXIMITE
  PATRIMOINE: {
    BASE: '/patrimoine',
    SITES: '/patrimoine/sites',
    SITE_BY_ID: (id: number) => `/patrimoine/sites/${id}`,
    MONUMENTS: '/patrimoine/monuments',
    MONUMENTS_BY_TYPE: (type: string) => `/patrimoine/monuments/type/${type}`,
    VESTIGES: '/patrimoine/vestiges',
    VESTIGES_BY_TYPE: (type: string) => `/patrimoine/vestiges/type/${type}`,
    RECHERCHE: '/patrimoine/search',
    POPULAIRES: '/patrimoine/populaires',
    PARCOURS: '/patrimoine/parcours',
    GALERIE: (siteId: number) => `/patrimoine/sites/${siteId}/galerie`,
    STATISTIQUES: '/patrimoine/statistics',
    PROXIMITE: '/patrimoine/proximite', // ✅ AJOUTÉ : Endpoint manquant
    RECOMMENDATIONS: '/patrimoine/recommendations',
    FEATURED_MONTHLY: '/patrimoine/featured-monthly',
    SUGGESTIONS: '/patrimoine/suggestions',
    CHECK_NAME: '/patrimoine/sites/check-name',
    STATISTIQUES_WILAYA: (wilayaId: number) => `/patrimoine/statistics/wilaya/${wilayaId}`,
  },

  // Métadonnées
  METADATA: {
    BASE: '/metadata',
    LANGUES: '/metadata/langues',
    CATEGORIES: '/metadata/categories',
    WILAYAS: '/metadata/wilayas',
    GENRES: '/metadata/genres',
    TYPES_OEUVRES: '/metadata/types-oeuvres',
    TYPES_EVENEMENTS: '/metadata/types-evenements',
    ROLES: '/metadata/roles',
    MATERIAUX: '/metadata/materiaux',
    TECHNIQUES: '/metadata/techniques',
    DAIRAS_BY_WILAYA: (wilayaId: number) => `/metadata/wilayas/${wilayaId}/dairas`,
    COMMUNES_BY_DAIRA: (dairaId: number) => `/metadata/dairas/${dairaId}/communes`,
    SEARCH_WILAYAS: '/metadata/wilayas/search',
    SEARCH_CATEGORIES: '/metadata/categories/search',
    STATISTICS: '/metadata/statistics',
  },

  // Utilisateurs
  USERS: {
    BASE: '/users',
    BY_ID: (id: number) => `/users/${id}`,
    SEARCH: '/users/search',
    VALIDATE_PROFESSIONAL: (id: number) => `/users/${id}/validate-professional`,
    SUSPEND: (id: number) => `/users/${id}/suspend`,
    ACTIVATE: (id: number) => `/users/${id}/activate`,
    STATISTICS: '/users/statistics',
  },

  // Tags
  TAGS: {
    BASE: '/tags',
    POPULAR: '/tags/popular',
    BY_TYPE: (type: string) => `/tags/by-type/${type}`,
    BY_CATEGORIES: '/tags/by-categories',
    ANALYZE_CONTENT: '/tags/analyze-content',
    SEARCH: '/tags/search',
    INCREMENT_USAGE: (id: number) => `/tags/${id}/increment-usage`,
    POPULAR_BY_CONTEXT: '/tags/popular-by-context',
  },

  // Médias/Upload
  UPLOAD: {
    BASE: '/upload',
    IMAGE: '/upload/image',
    DOCUMENT: '/upload/document',
    VIDEO: '/upload/video',
    AUDIO: '/upload/audio',
    DELETE: (id: string) => `/upload/${id}`,
  },

  // Notifications
  NOTIFICATIONS: {
    BASE: '/notifications',
    UNREAD: '/notifications/unread',
    MARK_AS_READ: (id: number) => `/notifications/${id}/mark-read`,
    MARK_ALL_READ: '/notifications/mark-all-read',
    DELETE: (id: number) => `/notifications/${id}`,
  },

  // Statistiques globales
  STATS: {
    DASHBOARD: '/stats/dashboard',
    OEUVRES: '/stats/oeuvres',
    EVENEMENTS: '/stats/evenements',
    PATRIMOINE: '/stats/patrimoine',
    USERS: '/stats/users',
    ACTIVITY: '/stats/activity',
  },

  // Système
  SYSTEM: {
    HEALTH: '/health',
    VERSION: '/version',
    CONFIG: '/config',
  }
} as const;

// =============================================================================
// CONFIGURATION DES HEADERS PAR DÉFAUT
// =============================================================================

export const DEFAULT_HEADERS = {
  'Content-Type': 'application/json',
  'Accept': 'application/json',
  'X-Requested-With': 'XMLHttpRequest',
};

// =============================================================================
// CODES DE STATUT HTTP
// =============================================================================

export const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  UNPROCESSABLE_ENTITY: 422,
  TOO_MANY_REQUESTS: 429,
  SERVER_ERROR: 500,
  SERVICE_UNAVAILABLE: 503,
};

// =============================================================================
// MESSAGES D'ERREUR PAR DÉFAUT
// =============================================================================

export const ERROR_MESSAGES = {
  NETWORK: 'Erreur de connexion au serveur',
  TIMEOUT: 'La requête a expiré',
  UNAUTHORIZED: 'Vous devez vous connecter pour accéder à cette ressource',
  FORBIDDEN: 'Vous n\'avez pas les permissions nécessaires',
  NOT_FOUND: 'Ressource introuvable',
  SERVER_ERROR: 'Erreur serveur, veuillez réessayer plus tard',
  VALIDATION: 'Les données fournies sont invalides',
  UNKNOWN: 'Une erreur inattendue s\'est produite',
};

// =============================================================================
// CONFIGURATION DE LA PAGINATION
// =============================================================================

export const PAGINATION_CONFIG = {
  DEFAULT_PAGE: 1,
  DEFAULT_LIMIT: 12,
  LIMITS: [6, 12, 24, 48],
  MAX_LIMIT: 100,
};

// =============================================================================
// CONFIGURATION DU CACHE
// =============================================================================

export const CACHE_CONFIG = {
  // Durées de cache par type de ressource (en ms)
  DURATIONS: {
    METADATA: 24 * 60 * 60 * 1000, // 24 heures
    USER_PROFILE: 10 * 60 * 1000,   // 10 minutes
    OEUVRES_LIST: 5 * 60 * 1000,    // 5 minutes
    OEUVRE_DETAIL: 10 * 60 * 1000,  // 10 minutes
    SEARCH_RESULTS: 2 * 60 * 1000,  // 2 minutes
    STATISTICS: 15 * 60 * 1000,     // 15 minutes
  },
  
  // Clés de cache
  KEYS: {
    METADATA: 'cache_metadata',
    USER: 'cache_user',
    OEUVRES: 'cache_oeuvres',
    EVENEMENTS: 'cache_evenements',
    PATRIMOINE: 'cache_patrimoine',
  }
};

// =============================================================================
// CONFIGURATION DES UPLOADS
// =============================================================================

export const UPLOAD_CONFIG = {
  // Tailles maximales (en octets)
  MAX_SIZE: {
    IMAGE: 5 * 1024 * 1024,      // 5 MB
    DOCUMENT: 10 * 1024 * 1024,  // 10 MB
    VIDEO: 100 * 1024 * 1024,    // 100 MB
    AUDIO: 20 * 1024 * 1024,     // 20 MB
  },
  
  // Types MIME acceptés
  ACCEPTED_TYPES: {
    IMAGE: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
    DOCUMENT: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
    VIDEO: ['video/mp4', 'video/mpeg', 'video/quicktime'],
    AUDIO: ['audio/mpeg', 'audio/wav', 'audio/ogg'],
  },
  
  // Extensions acceptées
  ACCEPTED_EXTENSIONS: {
    IMAGE: ['.jpg', '.jpeg', '.png', '.gif', '.webp'],
    DOCUMENT: ['.pdf', '.doc', '.docx'],
    VIDEO: ['.mp4', '.mpeg', '.mov'],
    AUDIO: ['.mp3', '.wav', '.ogg'],
  }
};

// =============================================================================
// EXPORT PAR DÉFAUT
// =============================================================================

export default {
  API_CONFIG,
  API_ENDPOINTS,
  DEFAULT_HEADERS,
  HTTP_STATUS,
  ERROR_MESSAGES,
  PAGINATION_CONFIG,
  CACHE_CONFIG,
  UPLOAD_CONFIG,
};