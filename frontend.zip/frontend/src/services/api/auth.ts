// src/services/api/auth.ts - Service d'authentification avec support photo

import { apiClient } from './client';
import { API_ENDPOINTS } from '../../config/api';
import type { 
  LoginCredentials, 
  RegisterData, 
  AuthResponse, 
  User, 
  UpdateProfileData, 
  ChangePasswordData,
  PhotoUploadResponse
} from '../../types/user';

export class AuthService {
  constructor(private client = apiClient) {}

  // ==========================================================================
  // AUTHENTIFICATION
  // ==========================================================================

  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    try {
      console.log('🔐 Tentative de connexion...');
      
      const response = await this.client.post<AuthResponse>(
        API_ENDPOINTS.AUTH.LOGIN, 
        credentials,
        { skipAuth: true, cache: false }
      );
      
      if (response.token) {
        this.client.setToken(response.token);
        console.log('✅ Connexion réussie');
      }
      
      return response;
    } catch (error) {
      console.error('❌ Erreur de connexion:', error);
      throw error;
    }
  }

  async register(data: RegisterData): Promise<AuthResponse> {
    try {
      console.log('📝 Tentative d\'inscription...');
      
      let photoUrl: string | undefined;

      // ✅ NOUVEAU : Gérer l'upload de photo si présente
      if (data.photo_profil && data.type_user !== 'visiteur') {
        try {
          console.log('📤 Upload de la photo de profil...');
          photoUrl = await this.uploadProfilePhoto(data.photo_profil);
          console.log('✅ Photo uploadée:', photoUrl);
        } catch (photoError) {
          console.warn('⚠️ Erreur lors de l\'upload de la photo, inscription sans photo:', photoError);
          // On continue l'inscription même si la photo échoue
        }
      }

      // ✅ CORRIGÉ : Adapter les données pour correspondre au backend
      const backendData = {
        nom: data.nom,
        prenom: data.prenom,
        email: data.email,
        password: data.password,
        telephone: data.telephone || '',
        date_naissance: data.date_naissance,
        biographie: data.bio || '',
        type_user: data.type_user,
        photo_url: photoUrl, // ✅ NOUVEAU : Ajouter l'URL de la photo si uploadée
        sexe: data.sexe,
        wilaya_residence: data.wilaya_residence,
        specialites: data.specialites,
        accepte_conditions: data.accepte_conditions,
        accepte_newsletter: data.accepte_newsletter
      };
      
      if (import.meta.env.DEV) {
        console.log('📤 Données envoyées:', { ...backendData, password: '[REDACTED]' });
      }
      
      const response = await this.client.post<AuthResponse>(
        API_ENDPOINTS.AUTH.REGISTER, 
        backendData,
        { skipAuth: true, cache: false }
      );
      
      if (response.token) {
        this.client.setToken(response.token);
        console.log('✅ Inscription réussie');
      }
      
      return response;
    } catch (error) {
      console.error('❌ Erreur d\'inscription:', error);
      throw error;
    }
  }

  // ✅ NOUVEAU : Méthode pour uploader une photo de profil
  async uploadProfilePhoto(file: File): Promise<string> {
    try {
      const response = await this.client.uploadFile(
        API_ENDPOINTS.UPLOAD.IMAGE,
        file,
        { type: 'profile' }
      ) as PhotoUploadResponse;

      if (response.success && response.data?.url) {
        return response.data.url;
      } else {
        throw new Error(response.error || 'Erreur lors de l\'upload de la photo');
      }
    } catch (error) {
      console.error('❌ Erreur upload photo:', error);
      throw new Error('Impossible d\'uploader la photo de profil');
    }
  }

  logout(): void {
    console.log('👋 Déconnexion');
    this.client.clearToken();
    this.client.clearCache();
  }

  // ==========================================================================
  // PROFIL UTILISATEUR
  // ==========================================================================

  async getProfile(): Promise<User> {
    try {
      return await this.client.get<User>(
        API_ENDPOINTS.AUTH.PROFILE, 
        undefined, 
        { cache: true }
      );
    } catch (error) {
      console.error('❌ Erreur de récupération du profil:', error);
      
      // Si le token est invalide, nettoyer et relancer l'erreur
      if (error instanceof Error && error.message.includes('Token expiré')) {
        this.logout();
      }
      
      throw error;
    }
  }

  async updateProfile(data: UpdateProfileData): Promise<User> {
    try {
      console.log('📝 Mise à jour du profil...');

      let updateData = { ...data };

      // ✅ NOUVEAU : Gérer l'upload de nouvelle photo si présente
      if (data.photo_profil) {
        try {
          console.log('📤 Upload de la nouvelle photo de profil...');
          const photoUrl = await this.uploadProfilePhoto(data.photo_profil);
          updateData.photo_url = photoUrl;
          // Supprimer le fichier des données à envoyer
          delete updateData.photo_profil;
          console.log('✅ Nouvelle photo uploadée:', photoUrl);
        } catch (photoError) {
          console.error('❌ Erreur lors de l\'upload de la photo:', photoError);
          throw new Error('Impossible d\'uploader la nouvelle photo de profil');
        }
      }
      
      const response = await this.client.put<User>(
        API_ENDPOINTS.AUTH.PROFILE, 
        updateData, 
        { cache: false }
      );
      
      console.log('✅ Profil mis à jour');
      return response;
    } catch (error) {
      console.error('❌ Erreur de mise à jour du profil:', error);
      throw error;
    }
  }

  async changePassword(data: ChangePasswordData): Promise<void> {
    try {
      console.log('🔒 Changement de mot de passe...');
      
      await this.client.patch<void>(
        API_ENDPOINTS.AUTH.CHANGE_PASSWORD, 
        data, 
        { cache: false }
      );
      
      console.log('✅ Mot de passe changé');
    } catch (error) {
      console.error('❌ Erreur de changement de mot de passe:', error);
      throw error;
    }
  }

  // ✅ NOUVEAU : Supprimer la photo de profil
  async removeProfilePhoto(): Promise<User> {
    try {
      console.log('🗑️ Suppression de la photo de profil...');
      
      const response = await this.client.put<User>(
        API_ENDPOINTS.AUTH.PROFILE, 
        { photo_url: null }, 
        { cache: false }
      );
      
      console.log('✅ Photo de profil supprimée');
      return response;
    } catch (error) {
      console.error('❌ Erreur de suppression de la photo:', error);
      throw error;
    }
  }

  // ==========================================================================
  // VÉRIFICATIONS DE STATUT
  // ==========================================================================

  async checkAuthStatus(): Promise<User | null> {
    try {
      // Vérifier si on a un token valide
      const info = this.client.getInfo();
      if (!info.hasToken) {
        return null;
      }

      // Essayer de récupérer le profil
      const user = await this.getProfile();
      return user;
    } catch (error) {
      console.error('❌ Erreur de vérification du statut:', error);
      this.logout();
      return null;
    }
  }

  // ==========================================================================
  // PERMISSIONS ET RÔLES (inchangé)
  // ==========================================================================

  hasRole(user: User | null, role: string): boolean {
    if (!user?.Roles) return false;
    return user.Roles.some(r => r.nom_role.toLowerCase() === role.toLowerCase());
  }

  hasAnyRole(user: User | null, roles: string[]): boolean {
    if (!user?.Roles) return false;
    return roles.some(role => this.hasRole(user, role));
  }

  hasPermission(user: User | null, permission: string): boolean {
    if (!user?.Roles) return false;
    return user.Roles.some(role => 
      role.permissions && role.permissions.includes(permission)
    );
  }

  // ==========================================================================
  // VÉRIFICATIONS MÉTIER SPÉCIFIQUES (inchangé)
  // ==========================================================================

  isAdmin(user: User | null): boolean {
    return this.hasRole(user, 'Admin');
  }

  isModerator(user: User | null): boolean {
    return this.hasRole(user, 'Modérateur') || this.isAdmin(user);
  }

  isProfessional(user: User | null): boolean {
    if (!user) return false;
    const professionalTypes = [
      'ecrivain', 'journaliste', 'scientifique', 'acteur', 'artiste', 
      'artisan', 'realisateur', 'musicien', 'photographe', 'danseur', 'sculpteur'
    ];
    return professionalTypes.includes(user.type_user);
  }

  isValidatedProfessional(user: User | null): boolean {
    return this.isProfessional(user) && user?.professionnel_valide === true;
  }

  isVisitor(user: User | null): boolean {
    return user?.type_user === 'visiteur';
  }

  // ==========================================================================
  // PERMISSIONS MÉTIER (inchangé)
  // ==========================================================================

  canCreateOeuvre(user: User | null): boolean {
    return this.isValidatedProfessional(user) || this.isAdmin(user);
  }

  canCreateEvenement(user: User | null): boolean {
    return (
      this.isValidatedProfessional(user) && 
      user?.Organisations && 
      user.Organisations.length > 0
    ) || this.isAdmin(user);
  }

  canModerate(user: User | null): boolean {
    return this.isModerator(user);
  }

  canManageUsers(user: User | null): boolean {
    return this.isAdmin(user);
  }

  canValidateProfessionals(user: User | null): boolean {
    return this.isAdmin(user);
  }

  canEditOwnContent(user: User | null, contentUserId: number): boolean {
    return user?.id_user === contentUserId || this.isAdmin(user);
  }

  canDeleteOwnContent(user: User | null, contentUserId: number): boolean {
    return user?.id_user === contentUserId || this.isAdmin(user);
  }

  // ==========================================================================
  // VÉRIFICATIONS DE STATUT DU COMPTE (inchangé)
  // ==========================================================================

  isAccountActive(user: User | null): boolean {
    return user?.statut_compte === 'actif';
  }

  isAccountPending(user: User | null): boolean {
    return user?.statut_compte === 'en_attente_validation';
  }

  isAccountSuspended(user: User | null): boolean {
    return user?.statut_compte === 'suspendu';
  }

  isAccountDeactivated(user: User | null): boolean {
    return user?.statut_compte === 'desactive';
  }

  // ==========================================================================
  // MESSAGES D'AIDE POUR L'UI (inchangé)
  // ==========================================================================

  getAccountStatusMessage(user: User | null): string | null {
    if (!user) return null;
    
    if (this.isAccountSuspended(user)) {
      return 'Votre compte a été suspendu. Contactez un administrateur.';
    }
    
    if (this.isAccountDeactivated(user)) {
      return 'Votre compte est désactivé.';
    }
    
    if (this.isProfessional(user) && this.isAccountPending(user)) {
      return 'Votre compte professionnel est en attente de validation.';
    }
    
    if (this.isProfessional(user) && !this.isValidatedProfessional(user)) {
      return 'Votre statut professionnel n\'est pas encore validé.';
    }
    
    return null;
  }

  getPermissionDeniedMessage(action: string): string {
    const messages: Record<string, string> = {
      'create_oeuvre': 'Vous devez être un professionnel validé pour créer des œuvres.',
      'create_evenement': 'Vous devez être un professionnel validé et appartenir à une organisation pour créer des événements.',
      'moderate': 'Vous devez être modérateur ou administrateur pour effectuer cette action.',
      'admin': 'Vous devez être administrateur pour accéder à cette fonctionnalité.',
    };
    
    return messages[action] || 'Vous n\'avez pas les permissions nécessaires pour cette action.';
  }
}

// Instance singleton exportée
export const authService = new AuthService();